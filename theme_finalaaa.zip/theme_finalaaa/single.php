<?php
/**
 * The template for displaying all single posts
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <?php
        while (have_posts()) :
            the_post();
        ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('single-post'); ?>>
                
                <!-- Post Header -->
                <header class="post-header">
                    <div class="post-meta">
                        <span class="post-date"><?php echo get_the_date(); ?></span>
                        <span class="post-category"><?php the_category(', '); ?></span>
                        <span class="post-author">By <?php the_author(); ?></span>
                        <span class="reading-time"><?php echo engine_dynamo_display_reading_time(); ?></span>
                    </div>
                    
                    <h1 class="post-title"><?php the_title(); ?></h1>
                </header>

                <!-- Featured Image -->
                <?php if (has_post_thumbnail()) : ?>
                    <div class="post-featured-image">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>

                <!-- Post Content -->
                <div class="post-content">
                    <?php
                    the_content();

                    wp_link_pages(array(
                        'before' => '<div class="page-links">',
                        'after'  => '</div>',
                    ));
                    ?>
                </div>

                <!-- Post Footer -->
                <footer class="post-footer">
                    
                    <!-- Post Tags -->
                    <?php if (has_tag()) : ?>
                        <div class="post-tags">
                            <span class="tags-label">Tags:</span>
                            <?php the_tags('', ', ', ''); ?>
                        </div>
                    <?php endif; ?>

                    <!-- Social Share Buttons -->
                    <?php get_template_part('template-parts/social-share'); ?>

                    <!-- Social Media Links -->
                    <div class="social-following">
                        <h4>Follow us:</h4>
                        <div class="following-buttons">
                            <a href="https://www.facebook.com/profile.php?id=61580498813187" target="_blank" rel="noopener" class="follow-btn facebook">
                                <i class="fab fa-facebook-f"></i>
                                <span>Follow</span>
                            </a>
                            <a href="https://www.instagram.com/engine_dynamo/" target="_blank" rel="noopener" class="follow-btn instagram">
                                <i class="fab fa-instagram"></i>
                                <span>Follow</span>
                            </a>
                        </div>
                    </div>

                    <!-- Rating System -->
                    <div class="rating-system">
                        <h4>Rate this article</h4>
                        <div class="stars" data-post-id="<?php the_ID(); ?>">
                            <span class="star" data-rating="1" title="Poor">★</span>
                            <span class="star" data-rating="2" title="Fair">★</span>
                            <span class="star" data-rating="3" title="Good">★</span>
                            <span class="star" data-rating="4" title="Very Good">★</span>
                            <span class="star" data-rating="5" title="Excellent">★</span>
                        </div>
                        <div class="rating-info">
                            <div>
                                <span class="average-rating"><?php echo number_format(get_post_meta(get_the_ID(), '_average_rating', true) ?: 0, 1); ?></span>
                                <span class="rating-count"><?php 
                                    $ratings = get_post_meta(get_the_ID(), '_post_ratings', true);
                                    echo count($ratings ?: array()); 
                                ?> ratings</span>
                            </div>
                        </div>
                        
                        <!-- Rating Distribution -->
                        <div class="rating-distribution">
                            <?php
                            $ratings = get_post_meta(get_the_ID(), '_post_ratings', true) ?: array();
                            $total = count($ratings);
                            for ($i = 5; $i >= 1; $i--) {
                                $count = count(array_filter($ratings, function($rating) use ($i) { return $rating == $i; }));
                                $percentage = $total > 0 ? ($count / $total) * 100 : 0;
                            ?>
                            <div class="rating-bar">
                                <span class="rating-label"><?php echo $i; ?> stars</span>
                                <div class="rating-progress">
                                    <div class="rating-progress-fill" style="width: <?php echo $percentage; ?>%"></div>
                                </div>
                                <span class="rating-value"><?php echo $count; ?></span>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </footer>

            </article>

            <!-- Post Navigation -->
            <nav class="post-navigation">
                <div class="nav-previous">
                    <?php previous_post_link('%link', '← %title'); ?>
                </div>
                <div class="nav-next">
                    <?php next_post_link('%link', '%title →'); ?>
                </div>
            </nav>

            <!-- Related Posts -->
            <?php
            $related_posts = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => 3,
                'post__not_in' => array(get_the_ID()),
                'category__in' => wp_get_post_categories(get_the_ID()),
            ));

            if ($related_posts->have_posts()) :
            ?>
                <div class="related-posts">
                    <h3>Related Articles</h3>
                    <div class="related-posts-grid">
                        <?php
                        while ($related_posts->have_posts()) : $related_posts->the_post();
                        ?>
                            <div class="related-post">
                                <div class="related-post-thumbnail">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <?php the_post_thumbnail('article-thumbnail'); ?>
                                        <?php else : ?>
                                            <div class="placeholder-image">🚗</div>
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="related-post-content">
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    <div class="related-post-meta"><?php echo get_the_date(); ?></div>
                                </div>
                            </div>
                        <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Comments -->
            <?php
            // If comments are open or we have at least one comment, load up the comment template.
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
            ?>

            <!-- Newsletter Signup -->
            <div class="newsletter-signup-section">
                <h3>Stay Updated</h3>
                <p>Get the latest automotive insights, reviews, and maintenance tips delivered to your inbox.</p>

                <form class="newsletter-form" method="post" action="">
                    <input type="email" name="newsletter_email" placeholder="Enter your email address" required>
                    <button type="submit" class="btn btn-primary">Subscribe</button>
                </form>
                <div class="newsletter-message"></div>
            </div>

        <?php
        endwhile;
        ?>

    </div>
</main>

<?php
get_footer();