<?php
/**
 * The main template file - HOMEPAGE
 * This shows the hero section + featured articles
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1 class="hero-title">
                        <span class="engine">ENGINE</span>
                        <span class="dynamo">DYNAMO</span>
                    </h1>
                    <p class="hero-tagline">Premium automotive writing — deep reviews, real tips.</p>
                    <p class="hero-description">High-performance guides, buying advice, and maintenance tips — delivered with cinematic design and modern interaction.</p>
                    
                    <div class="hero-buttons">
                        <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn btn-primary">Latest Posts</a>
                        <a href="<?php echo home_url('/about'); ?>" class="btn btn-secondary">About</a>
                    </div>
                </div>
                
                <div class="hero-car">
                    <div class="car-3d">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/car-3d.svg" alt="3D Car" class="car-image">
                    </div>
                    <div class="car-glow"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Articles Section -->
    <section class="featured-section">
        <div class="container">
            <h2 class="section-title">Featured Articles</h2>
            
            <div class="articles-grid">
                <?php
                // Get latest posts as featured
                $featured_posts = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    'post_status' => 'publish'
                ));
                
                if ($featured_posts->have_posts()) :
                    while ($featured_posts->have_posts()) : $featured_posts->the_post();
                ?>
                    <article class="article-card">
                        <div class="article-thumbnail">
                            <a href="<?php the_permalink(); ?>">
                                <div class="placeholder-image">
                                    <span class="placeholder-icon">🚗</span>
                                    <span class="placeholder-text">Automotive</span>
                                </div>
                            </a>
                        </div>
                        
                        <h3 class="article-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        
                        <div class="article-meta">
                            <span class="article-date"><?php echo get_the_date(); ?></span>
                            <span class="article-category"><?php the_category(', '); ?></span>
                        </div>
                        
                        <div class="article-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        
                        <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                    </article>
                <?php
                    endwhile;
                    wp_reset_postdata();
                endif; ?>
            </div>
        </div>
    </section>
</main><!-- #main -->

<?php
get_footer();
