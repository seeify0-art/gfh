<?php
/**
 * Enqueue scripts and styles for the hero slider
 */
function theme_finaldd_enqueue_hero_slider() {
    // Enqueue header CSS
    wp_enqueue_style(
        'header-styles',
        get_template_directory_uri() . '/assets/css/header.css',
        array(),
        '1.0.0'
    );
    
    // Enqueue footer CSS
    wp_enqueue_style(
        'footer-styles',
        get_template_directory_uri() . '/assets/css/footer.css',
        array(),
        '1.0.0'
    );

    // Only on front page
    if (is_front_page()) {
        // Enqueue hero main CSS
        wp_enqueue_style(
            'hero-main',
            get_template_directory_uri() . '/assets/css/hero-main.css',
            array(),
            '1.0.0'
        );
        
        // Enqueue GSAP
        wp_enqueue_script(
            'gsap',
            'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js',
            array(),
            '3.12.2',
            true
        );
        
        // Enqueue title animation
        wp_enqueue_script(
            'title-animation',
            get_template_directory_uri() . '/js/title-animation.js',
            array('gsap'),
            '1.0.0',
            true
        );
        
        // Enqueue Swiper CSS
        wp_enqueue_style(
            'swiper-css',
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
            array(),
            '11.0.0'
        );

        // Enqueue Swiper JS
        wp_enqueue_script(
            'swiper-js',
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
            array('jquery'),
            '11.0.0',
            true
        );

        // Enqueue custom hero slider JS
        wp_enqueue_script(
            'hero-slider',
            get_template_directory_uri() . '/js/hero-slider.js',
            array('jquery', 'swiper-js'),
            '1.0.0',
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'theme_finaldd_enqueue_hero_slider');