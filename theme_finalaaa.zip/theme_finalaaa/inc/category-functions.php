<?php

/* Function to display specially formatted category titles */
function engine_dynamo_get_formatted_category_title($category) {
    $title = $category->name;
    
    switch($category->slug) {
        case 'maintenance-tips':
            return sprintf(
                '<h1 class="category-title maintenance-tips">
                    <span class="line1">Maintenance</span>
                    <span class="line2">Tips</span>
                </h1>'
            );
            
        case 'tires-parts':
            return sprintf(
                '<h1 class="category-title tires-parts">
                    <span class="line1">Tires</span>
                    <span class="symbol">&amp;</span>
                    <span class="line2">Parts</span>
                </h1>'
            );
            
        case 'car-reviews':
            return sprintf(
                '<h1 class="category-title car-reviews">
                    <span class="line1">Car</span>
                    <span class="line2">Reviews</span>
                </h1>'
            );
            
        default:
            return sprintf(
                '<h1 class="page-title">%s %s</h1>',
                esc_html__('Category:', 'engine-dynamo'),
                '<span class="category-name">' . esc_html($title) . '</span>'
            );
    }
}