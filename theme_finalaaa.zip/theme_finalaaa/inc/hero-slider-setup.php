// Add this inside your theme setup function
function enqueue_hero_slider_assets() {
    // Enqueue Swiper CSS
    wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css');
    
    // Enqueue custom hero slider CSS
    wp_enqueue_style('hero-slider-css', get_template_directory_uri() . '/assets/css/hero-slider.css');
    
    // Enqueue Swiper JS
    wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), null, true);
    
    // Enqueue custom hero slider JS
    wp_enqueue_script('hero-slider-js', get_template_directory_uri() . '/js/hero-slider.js', array('swiper-js'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_hero_slider_assets');