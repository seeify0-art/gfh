<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <!-- 404 Error Content -->
        <section class="error-404">
            <div class="error-content">
                <div class="error-illustration">
                    <div class="error-car">
                        <div class="car-body"></div>
                        <div class="car-wheels">
                            <div class="wheel"></div>
                            <div class="wheel"></div>
                        </div>
                        <div class="error-smoke"></div>
                    </div>
                </div>
                
                <div class="error-text">
                    <h1 class="error-title">404</h1>
                    <h2 class="error-subtitle">Page Not Found</h2>
                    <p class="error-description">
                        Oops! It looks like this page has taken a wrong turn. 
                        The content you're looking for might have been moved, deleted, or doesn't exist.
                    </p>
                    
                    <div class="error-actions">
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">
                            <span>🏠</span> Go Home
                        </a>
                        <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-secondary">
                            <span>📝</span> Browse Articles
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Search Section -->
            <div class="error-search pro-search-box">
                <h3 class="pro-search-title">Can't find what you're looking for?</h3>
                <p class="pro-search-desc">Try searching for it:</p>
                <div class="pro-search-form-wrap">
                    <?php get_search_form(); ?>
                </div>
            </div>
            
            <!-- Popular Posts -->
            <div class="error-popular">
                <h3 class="pro-popular-title">Popular Articles</h3>
                <div class="popular-posts-grid">
                    <?php
                    $popular_posts = new WP_Query(array(
                        'post_type' => 'post',
                        'posts_per_page' => 3,
                        'meta_key' => '_post_views',
                        'orderby' => 'meta_value_num',
                        'order' => 'DESC'
                    ));
                    if ($popular_posts->have_posts()) :
                        while ($popular_posts->have_posts()) : $popular_posts->the_post();
                    ?>
                        <article class="popular-post-card">
                            <div class="post-thumbnail">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('article-thumbnail'); ?>
                                <?php else : ?>
                                    <div class="placeholder-image">
                                        <span class="placeholder-icon">🚗</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="post-content">
                                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                <div class="post-meta">
                                    <span class="post-date"><?php echo get_the_date(); ?></span>
                                    <span class="post-views">👁️ <?php echo get_post_meta(get_the_ID(), '_post_views', true) ?: '0'; ?> views</span>
                                </div>
                            </div>
                        </article>
                    <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                    ?>
                        <div class="pro-no-articles">
                            <div class="pro-no-articles-icon">📝</div>
                            <h4>No Articles Yet</h4>
                            <p>We're working on creating amazing automotive content for you. Check back soon!</p>
                            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">Explore Homepage</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Links -->
            <div class="error-quick-links">
                <h3>Quick Navigation</h3>
                <div class="quick-links-grid">
                    <a href="<?php echo esc_url(home_url('/maintenance-tips')); ?>" class="quick-link">
                        <span class="link-icon">🔧</span>
                        <span class="link-text">Maintenance Tips</span>
                    </a>
                    <a href="<?php echo esc_url(home_url('/car-reviews')); ?>" class="quick-link">
                        <span class="link-icon">🚗</span>
                        <span class="link-text">Car Reviews</span>
                    </a>
                    <a href="<?php echo esc_url(home_url('/tires-parts')); ?>" class="quick-link">
                        <span class="link-icon">🛞</span>
                        <span class="link-text">Tires & Parts</span>
                    </a>
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="quick-link">
                        <span class="link-icon">📞</span>
                        <span class="link-text">Contact Us</span>
                    </a>
                </div>
            </div>
        </section>
        
    </div>
</main>

<?php
get_footer();
