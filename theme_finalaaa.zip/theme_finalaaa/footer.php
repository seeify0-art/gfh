<footer id="colophon" class="site-footer">
    <div class="footer-top">
        <div class="container">
            <div class="footer-grid">
                <!-- Brand Column -->
                <div class="footer-brand">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-logo">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.svg" alt="Engine Dynamo" loading="lazy" onerror="this.onerror=null;this.src='<?php echo get_template_directory_uri(); ?>/assets/images/logo.png';" />
                    </a>
                    <p class="footer-description">
                        Your trusted source for automotive excellence. Deep reviews, expert tips, and premium automotive content.
                    </p>
                    <div class="footer-social">
                        <a href="https://www.facebook.com/profile.php?id=61580498813187" target="_blank" rel="noopener" class="social-icon facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://www.instagram.com/engine_dynamo/" target="_blank" rel="noopener" class="social-icon instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="footer-links">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="<?php echo home_url('/about'); ?>">About Us</a></li>
                        <li><a href="<?php echo home_url('/blog'); ?>">Blog</a></li>
                        <li><a href="<?php echo home_url('/contact'); ?>">Contact</a></li>
                        <li><a href="<?php echo home_url('/popular'); ?>">Popular Posts</a></li>
                    </ul>
                </div>

                <!-- Categories -->
                <div class="footer-categories">
                    <h3>Categories</h3>
                    <ul>
                        <li><a href="<?php echo get_category_link(get_cat_ID('Car Reviews')); ?>">Car Reviews</a></li>
                        <li><a href="<?php echo get_category_link(get_cat_ID('Maintenance Tips')); ?>">Maintenance Tips</a></li>
                        <li><a href="<?php echo get_category_link(get_cat_ID('Tires & Parts')); ?>">Tires & Parts</a></li>
                        <li><a href="<?php echo get_category_link(get_cat_ID('DIY Fixes')); ?>">DIY Fixes</a></li>
                    </ul>
                </div>

                <!-- Newsletter -->
                <div class="footer-newsletter">
                    <h3>Stay Updated</h3>
                    <p>Subscribe to our newsletter for the latest automotive news and exclusive content.</p>
                    <form class="newsletter-form" id="footer-newsletter-form" method="post">
                        <?php wp_nonce_field('engine_dynamo_newsletter', 'newsletter_nonce'); ?>
                        <div class="input-group">
                            <input type="email" name="email" class="email-input" placeholder="Your email address" required>
                            <button type="submit" class="subscribe-btn">Subscribe</button>
                        </div>
                        <div class="newsletter-response"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
        <div class="container">
            <div class="footer-bottom-content">
                <div class="footer-copyright">
                    © <?php echo date('Y'); ?> ENGINE DYNAMO. All rights reserved.
                </div>
                <div class="footer-legal">
                    <a href="<?php echo home_url('/privacy-policy'); ?>">Privacy Policy</a>
                    <a href="<?php echo home_url('/terms-conditions'); ?>">Terms & Conditions</a>
                    <a href="<?php echo home_url('/disclaimer'); ?>">Disclaimer</a>
                </div>
            </div>
        </div>
    </div>
</footer>

</div><!-- #page -->

<?php 
// Load newsletter popup template
get_template_part('template-parts/newsletter-popup');

wp_footer(); 
?>

</body>
</html>
