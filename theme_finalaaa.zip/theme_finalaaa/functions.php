<?php
/**
 * Engine Dynamo Theme Functions
 * 
 * @package EngineDynamo
 * @version 1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Custom Navigation Walker
class Engine_Dynamo_Nav_Walker extends Walker_Nav_Menu {
    public function start_lvl(&$output, $depth = 0, $args = null) {
        if (isset($args->item_spacing) && 'discard' === $args->item_spacing) {
            $t = '';
            $n = '';
        } else {
            $t = "\t";
            $n = "\n";
        }
        $indent = str_repeat($t, $depth);
        $classes = ['dropdown-menu'];
        
        $class_names = implode(' ', apply_filters('nav_menu_submenu_css_class', $classes, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $output .= "{$n}{$indent}<ul$class_names>{$n}";
    }

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        if (isset($args->item_spacing) && 'discard' === $args->item_spacing) {
            $t = '';
            $n = '';
        } else {
            $t = "\t";
            $n = "\n";
        }
        $indent = ($depth) ? str_repeat($t, $depth) : '';

        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'nav-item';
        
        // Add dropdown class if item has children
        if ($args->walker->has_children) {
            $classes[] = 'dropdown';
        }

        $class_names = implode(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth);
        $id = $id ? ' id="' . esc_attr($id) . '"' : '';

        $output .= $indent . '<li' . $id . $class_names . '>';

        $atts = array();
        $atts['title']  = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';
        $atts['rel']    = !empty($item->xfn) ? $item->xfn : '';
        $atts['href']   = !empty($item->url) ? $item->url : '';
        $atts['class']  = 'nav-link';

        // If this menu item is a Custom Link but its title matches a category
        // we expect to link to the category archive. Some menus were created
        // as Custom Links (or contain preview URLs) and point to single posts
        // (eg. hello-world preview). Prefer resolving to the proper category
        // archive where possible. This only affects top-level parent items and
        // the Blog label to avoid changing intentional custom links.
        if (isset($item->object) && $item->object === 'custom') {
            // Use the raw menu item title (we haven't applied filters yet)
            $menu_title_raw = isset($item->title) ? trim($item->title) : '';
            $normalized_title = $menu_title_raw;
            $resolved = null;

            // Map known human-readable titles to their slugs
            $title_to_slug = array(
                'Maintenance Tips' => 'maintenance-tips',
                'Tires & Parts' => 'tires-parts',
                'Car Reviews' => 'car-reviews'
            );

            if (isset($title_to_slug[$normalized_title])) {
                $resolved = engine_dynamo_resolve_category_link($title_to_slug[$normalized_title]);
            } elseif (strcasecmp($normalized_title, 'Blog') === 0) {
                // Blog should point to the posts page if configured
                $blog_page_id = get_option('page_for_posts');
                if ($blog_page_id && get_post_status($blog_page_id)) {
                    $resolved = get_permalink($blog_page_id);
                } else {
                    $resolved = home_url('/');
                }
            }

            // If we found a sensible resolved URL, and it's different from the
            // current href (or current href looks like a preview/single-post URL),
            // replace the menu href. This avoids touching legitimate custom links.
            if ($resolved) {
                $current_href = isset($atts['href']) ? $atts['href'] : '';
                $looks_like_bad = false;
                if (empty($current_href)) $looks_like_bad = true;
                // common preview/single-post patterns (hello-world, date-based, customize)
                if (strpos($current_href, 'hello-world') !== false || strpos($current_href, '?customize') !== false || preg_match('#/20\d{2}/#', $current_href)) {
                    $looks_like_bad = true;
                }

                if ($looks_like_bad || untrailingslashit($current_href) !== untrailingslashit($resolved)) {
                    $atts['href'] = $resolved;
                }
            }
        }

        // If item has children, add dropdown toggle
        if ($args->walker->has_children) {
            $atts['class'] .= ' dropdown-toggle';
            $atts['data-bs-toggle'] = 'dropdown';
            $atts['aria-expanded'] = 'false';
        }

        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);

        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        /** This filter is documented in wp-includes/post-template.php */
        $title = apply_filters('the_title', $item->title, $item->ID);
        $title = apply_filters('nav_menu_item_title', $title, $item, $args, $depth);

        // Special formatting for specific menu items
        $special_titles = array(
            'Maintenance Tips' => array(
                'class' => 'maintenance-tips',
                'line1' => 'Maintenance',
                'line2' => 'Tips'
            ),
            'Tires & Parts' => array(
                'class' => 'tires-parts',
                'lines' => array(
                    'Tires',
                    '&',
                    'Parts'
                )
            ),
            'Car Reviews' => array(
                'class' => 'car-reviews',
                'line1' => 'Car',
                'line2' => 'Reviews'
            )
        );

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $args->link_before;
        
        // Check if this menu item needs special formatting
        if (isset($special_titles[$title])) {
            $format = $special_titles[$title];
            $item_output .= '<span class="category-title ' . $format['class'] . '">';
            
            if (isset($format['lines'])) {
                // For Tires & Parts with three lines
                foreach ($format['lines'] as $index => $line) {
                    if ($line === '&') {
                        $item_output .= '<span class="symbol">' . $line . '</span>';
                    } else {
                        $class = 'line' . ($index === 0 ? '1' : '2');
                        $item_output .= '<span class="' . $class . '">' . $line . '</span>';
                    }
                }
            } else {
                // For other two-line titles
                $item_output .= '<span class="line1">' . $format['line1'] . '</span>';
                $item_output .= '<span class="line2">' . $format['line2'] . '</span>';
            }
            
            $item_output .= '</span>';
        } else {
            $item_output .= $title;
        }
        
        $item_output .= $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

// Theme setup
function engine_dynamo_setup() {
    // Add theme support
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'script',
        'style',
    ));
    add_theme_support('custom-logo');
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('automatic-feed-links');
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('wp-block-styles');
    
    // Add custom image sizes for social sharing
    add_image_size('social-share', 1200, 630, true);
    add_image_size('twitter-card', 800, 418, true);

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'engine-dynamo'),
        'footer' => __('Footer Menu', 'engine-dynamo'),
    ));

    // Add image sizes
    add_image_size('hero-image', 1200, 600, true);
    add_image_size('article-thumbnail', 400, 250, true);
    add_image_size('car-3d', 800, 500, true);
}
add_action('after_setup_theme', 'engine_dynamo_setup');

// Create categories on theme activation
function engine_dynamo_create_categories() {
    // Parent categories
    $parent_categories = array(
        'Maintenance Tips' => 'maintenance-tips',
        'Tires & Parts' => 'tires-parts',
        'Car Reviews' => 'car-reviews'
    );

    $parent_ids = array();
    foreach ($parent_categories as $name => $slug) {
        if (!get_category_by_slug($slug)) {
            $parent_ids[$slug] = wp_insert_category(array(
                'cat_name' => $name,
                'category_nicename' => $slug
            ));
        } else {
            $cat = get_category_by_slug($slug);
            $parent_ids[$slug] = $cat->term_id;
        }
    }

    // Subcategories
    $subcategories = array(
        // Maintenance Tips subcategories
        array('name' => 'Engine Care', 'slug' => 'engine-care', 'parent' => 'maintenance-tips'),
        array('name' => 'Tire & Wheel Care', 'slug' => 'tire-wheel-care', 'parent' => 'maintenance-tips'),
        array('name' => 'DIY Fixes', 'slug' => 'diy-fixes', 'parent' => 'maintenance-tips'),
        array('name' => 'Cleaning & Detailing', 'slug' => 'cleaning-detailing', 'parent' => 'maintenance-tips'),

        // Tires & Parts subcategories
        array('name' => 'Best Tire Brands', 'slug' => 'best-tire-brands', 'parent' => 'tires-parts'),
        array('name' => 'Car Accessories', 'slug' => 'car-accessories', 'parent' => 'tires-parts'),
        array('name' => 'Auto Parts Reviews', 'slug' => 'auto-parts-reviews', 'parent' => 'tires-parts'),

        // Car Reviews subcategories
        array('name' => 'Toyota', 'slug' => 'toyota', 'parent' => 'car-reviews'),
        array('name' => 'Honda', 'slug' => 'honda', 'parent' => 'car-reviews'),
        array('name' => 'Budget Cars', 'slug' => 'budget-cars', 'parent' => 'car-reviews'),
    );

    foreach ($subcategories as $subcat) {
        if (!get_category_by_slug($subcat['slug']) && isset($parent_ids[$subcat['parent']])) {
            wp_insert_category(array(
                'cat_name' => $subcat['name'],
                'category_nicename' => $subcat['slug'],
                'category_parent' => $parent_ids[$subcat['parent']]
            ));
        }
    }
}

// Ensure default categories exist on init (useful when theme is imported or menus are created before activation)
function engine_dynamo_ensure_default_categories() {
    $slugs = array('maintenance-tips', 'tires-parts', 'car-reviews');
    $missing = false;
    foreach ($slugs as $s) {
        if (!get_category_by_slug($s)) {
            $missing = true;
            break;
        }
    }

    // Some WP bootstrap paths (customizer, recovery, early admin requests)
    // may not have all taxonomy helper functions available yet. Guard the
    // call to avoid fatal errors in those cases. If wp_insert_category() is
    // not defined, schedule creation for a later hook where core is loaded.
    if ($missing) {
        if (function_exists('wp_insert_category')) {
            // Safe to create now
            engine_dynamo_create_categories();
        } else {
            // Defer to after_setup_theme which runs later in bootstrap
            add_action('after_setup_theme', 'engine_dynamo_create_categories');
        }
    }
}
add_action('init', 'engine_dynamo_ensure_default_categories');

/**
 * Ensure the top-level "Blog" nav item always points to the posts archive
 * when the menu entry contains a single-post or preview URL. This runs at
 * render-time and does not modify menu data in the database.
 */
function engine_dynamo_fix_blog_menu_href($atts, $item, $args, $depth) {
    if (empty($item->title)) return $atts;

    // Match 'Blog' label (case-insensitive)
    if (strcasecmp(trim($item->title), 'blog') !== 0) {
        return $atts;
    }

    // Determine desired posts archive URL
    $blog_page_id = get_option('page_for_posts');
    if ($blog_page_id && get_post_status($blog_page_id)) {
        $desired = get_permalink($blog_page_id);
    } else {
        $desired = home_url('/');
    }

    $current = isset($atts['href']) ? $atts['href'] : '';

    // Heuristic: if the current href looks like a dated post permalink,
    // or contains common preview markers, treat it as incorrect and replace.
    $looks_like_post = false;
    if (strpos($current, 'hello-world') !== false || strpos($current, '?customize') !== false) {
        $looks_like_post = true;
    }
    if (preg_match('#/20\d{2}/#', $current)) {
        $looks_like_post = true;
    }

    if ($looks_like_post || untrailingslashit($current) !== untrailingslashit($desired)) {
        $atts['href'] = $desired;
    }

    return $atts;
}
add_filter('nav_menu_link_attributes', 'engine_dynamo_fix_blog_menu_href', 20, 4);

// Enqueue scripts and styles
function engine_dynamo_scripts() {
    // Main stylesheet
    wp_enqueue_style('engine-dynamo-style', get_stylesheet_uri(), array(), time());
    
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap', array(), null);
    
    // Font Awesome for social icons
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
    
    // Component styles
    wp_enqueue_style('engine-dynamo-hero', get_template_directory_uri() . '/assets/css/hero-styles.css', array('engine-dynamo-style'), time());
    wp_enqueue_style('engine-dynamo-hero-gradient', get_template_directory_uri() . '/assets/css/hero-gradient.css', array('engine-dynamo-hero'), time());
    wp_enqueue_style('engine-dynamo-header', get_template_directory_uri() . '/assets/css/header-new.css', array('engine-dynamo-style'), time());
    wp_enqueue_style('engine-dynamo-rating', get_template_directory_uri() . '/assets/css/rating-system.css', array('engine-dynamo-style'), time());
    wp_enqueue_style('engine-dynamo-newsletter', get_template_directory_uri() . '/assets/css/newsletter.css', array('engine-dynamo-style'), time());
    wp_enqueue_style('engine-dynamo-share-buttons', get_template_directory_uri() . '/assets/css/share-buttons.css', array('engine-dynamo-style'), time());
    wp_enqueue_style('engine-dynamo-category-nav', get_template_directory_uri() . '/assets/css/category-navigation.css', array('engine-dynamo-style'), time());
    
    // Enhanced category header styles
    wp_enqueue_style('engine-dynamo-category-header', get_template_directory_uri() . '/assets/css/enhanced-category-header.css', array('engine-dynamo-style'), time());

    // Comments and forms styles
    // Note: comments CSS was intentionally not enqueued to preserve the site's existing comment design.

    // Sidebar styles
    wp_enqueue_style('engine-dynamo-sidebar', get_template_directory_uri() . '/assets/css/sidebar.css', array(), time());
    
    // Pagination styles
    wp_enqueue_style('engine-dynamo-pagination', get_template_directory_uri() . '/assets/css/pagination.css', array(), time());
    
    // Main JavaScript
    wp_enqueue_script('engine-dynamo-script', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0.0', true);
    // Newsletter script (handles popup + inline newsletter forms)
    wp_enqueue_script('engine-dynamo-newsletter', get_template_directory_uri() . '/js/newsletter.js', array(), time(), true);
    // Localize an object matching the front-end code expectations
    wp_localize_script('engine-dynamo-newsletter', 'engineDynamoAjax', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('engine_dynamo_nonce'),
        'themeUrl' => get_template_directory_uri(),
    ));

    // Comment reply + AJAX script (depends on newsletter localization to have engineDynamoAjax)
    wp_enqueue_script('engine-dynamo-comments', get_template_directory_uri() . '/js/comment.js', array('engine-dynamo-newsletter'), time(), true);
    
    // Share buttons script
    wp_enqueue_script('engine-dynamo-share', get_template_directory_uri() . '/js/share-buttons.js', array('jquery'), time(), true);

    // Swiper CSS (CDN) for hero slider
    wp_enqueue_style('swiper-cdn', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.0');

    // Swiper JS (CDN) - load in footer
    wp_enqueue_script('swiper-cdn', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.0', true);

    // Hero slider script (depends on Swiper)
    wp_enqueue_script('engine-dynamo-hero', get_template_directory_uri() . '/js/hero-slider.js', array('swiper-cdn', 'jquery'), '1.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('engine-dynamo-script', 'engine_dynamo_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('engine_dynamo_nonce'),
        'theme_url' => get_template_directory_uri(),
    ));
    
    // Critical inline hero CSS: ensure the hero gradient and large responsive sizing
    // are applied after other styles (helps in case of load-order or caching issues).
    $engine_hero_critical = "
    .hero-section .engine-dynamo, .hero-section .hero-title {
        font-size: clamp(4rem, 12vw, 12rem) !important;
        font-weight: 900 !important;
        line-height: 0.95 !important;
        -webkit-font-smoothing: antialiased !important;
        -moz-osx-font-smoothing: grayscale !important;
        text-rendering: optimizeLegibility !important;
    }
    
    .hero-section .engine-dynamo .engine,
    .hero-section .hero-title .engine {
        /* Richer teal → cyan → blue for the left word (ENGINE) */
        background: linear-gradient(90deg,#0ea5a4 0%,#06b6d4 40%,#3b82f6 80%) !important;
        -webkit-background-clip: text !important;
        background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        color: transparent !important;
        will-change: background-position !important;
        backface-visibility: hidden !important;
        -webkit-backface-visibility: hidden !important;
    }
    
    .hero-section .engine-dynamo .dynamo,
    .hero-section .hero-title .dynamo {
        /* Warm coral → orange → red for the right word (DYNAMO) to add punch */
        background: linear-gradient(90deg,#ff7a59 0%,#ff4d4d 55%,#e63946 100%) !important;
        -webkit-background-clip: text !important;
        background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        color: transparent !important;
        will-change: background-position !important;
        backface-visibility: hidden !important;
        -webkit-backface-visibility: hidden !important;
    }
    
    @supports (-webkit-background-clip: text) or (background-clip: text) {
        .hero-section .engine-dynamo .engine,
        .hero-section .engine-dynamo .dynamo {
            transform: translate3d(0, 0, 0) !important;
            -webkit-transform: translate3d(0, 0, 0) !important;
        }
    }
    ";
    // Attach after main stylesheet so it prints late in the head
    wp_add_inline_style('engine-dynamo-style', $engine_hero_critical);
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'engine_dynamo_scripts');

// Post view counter
function engine_dynamo_set_post_views($post_id) {
    $count_key = 'post_views_count';
    $count = get_post_meta($post_id, $count_key, true);
    if ($count == '') {
        delete_post_meta($post_id, $count_key);
        add_post_meta($post_id, $count_key, '0');
    } else {
        $count++;
        update_post_meta($post_id, $count_key, $count);
    }
}

function engine_dynamo_get_post_views($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    $count_key = 'post_views_count';
    $count = get_post_meta($post_id, $count_key, true);
    if ($count == '') {
        delete_post_meta($post_id, $count_key);
        add_post_meta($post_id, $count_key, '0');
        return "0";
    }
    return $count;
}

// Register widget areas
function engine_dynamo_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'engine-dynamo'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here.', 'engine-dynamo'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
    
    register_sidebar(array(
        'name' => __('Footer Widgets', 'engine-dynamo'),
        'id' => 'footer-widgets',
        'description' => __('Add footer widgets here.', 'engine-dynamo'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="footer-widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'engine_dynamo_widgets_init');

/**
 * Resolve a category link by trying slug, name, and sanitized variants.
 * Returns a URL string or null if not found.
 */
function engine_dynamo_resolve_category_link($slug_or_name) {
    if (empty($slug_or_name)) return null;

    // Try slug first
    $cat = get_category_by_slug($slug_or_name);
    if ($cat && !is_wp_error($cat)) {
        return get_category_link($cat->term_id);
    }

    // Try by name (get_cat_ID expects category name)
    $cat_id = get_cat_ID($slug_or_name);
    if ($cat_id && $cat_id > 0) {
        return get_category_link($cat_id);
    }

    // Try searching categories by name (loose match)
    $terms = get_terms(array(
        'taxonomy' => 'category',
        'hide_empty' => false,
        'search' => $slug_or_name,
        'number' => 1,
        'fields' => 'ids'
    ));
    if (!empty($terms) && !is_wp_error($terms)) {
        return get_category_link($terms[0]);
    }

    // Try sanitized slug from the provided string
    $sanitized = sanitize_title($slug_or_name);
    if ($sanitized && $sanitized !== $slug_or_name) {
        $cat2 = get_category_by_slug($sanitized);
        if ($cat2 && !is_wp_error($cat2)) {
            return get_category_link($cat2->term_id);
        }
    }

    return null;
}

// Fallback menu function
function engine_dynamo_fallback_menu() {
    echo '<ul class="nav-menu">';
    echo '<li class="nav-item"><a href="' . home_url('/') . '" class="nav-link">Home</a></li>';
    // Resolve the posts page reliably. If no 'Posts page' is set in Settings -> Reading,
    // fall back to the site's home URL so the link still navigates somewhere sensible.
    $blog_page_id = get_option('page_for_posts');
    if ($blog_page_id && get_post_status($blog_page_id)) {
        $blog_url = get_permalink($blog_page_id);
    } else {
        // No static posts page configured — use home URL as the fallback.
        $blog_url = home_url('/');
    }
    echo '<li class="nav-item"><a href="' . esc_url($blog_url) . '" class="nav-link">Blog</a></li>';
    echo '<li class="nav-item"><a href="' . home_url('/about') . '" class="nav-link">About</a></li>';

    // Maintenance Tips dropdown - link parent to category archive if exists
    $maintenance_tips_url = engine_dynamo_resolve_category_link('maintenance-tips') ?: get_permalink(get_option('page_for_posts'));
    echo '<li class="nav-item dropdown">';
    echo '<a href="' . $maintenance_tips_url . '" class="nav-link">Maintenance Tips</a>';
    echo '<ul class="dropdown-menu">';
    $engine_care_cat = get_category_by_slug('engine-care');
    $tire_care_cat = get_category_by_slug('tire-wheel-care');
    $diy_cat = get_category_by_slug('diy-fixes');
    $cleaning_cat = get_category_by_slug('cleaning-detailing');

    if ($engine_care_cat) echo '<li><a href="' . get_category_link($engine_care_cat->term_id) . '" class="dropdown-item">Engine Care</a></li>';
    if ($tire_care_cat) echo '<li><a href="' . get_category_link($tire_care_cat->term_id) . '" class="dropdown-item">Tire & Wheel Care</a></li>';
    if ($diy_cat) echo '<li><a href="' . get_category_link($diy_cat->term_id) . '" class="dropdown-item">DIY Fixes</a></li>';
    if ($cleaning_cat) echo '<li><a href="' . get_category_link($cleaning_cat->term_id) . '" class="dropdown-item">Cleaning & Detailing</a></li>';
    echo '</ul>';
    echo '</li>';

    // Tires & Parts dropdown - link parent to category archive if exists
    $tires_parts_url = engine_dynamo_resolve_category_link('tires-parts') ?: get_permalink(get_option('page_for_posts'));
    echo '<li class="nav-item dropdown">';
    echo '<a href="' . $tires_parts_url . '" class="nav-link">Tires & Parts</a>';
    echo '<ul class="dropdown-menu">';
    echo '<li><a href="' . get_category_link(get_cat_ID('Best Tire Brands')) . '" class="dropdown-item">Best Tire Brands</a></li>';
    echo '<li><a href="' . get_category_link(get_cat_ID('Car Accessories')) . '" class="dropdown-item">Car Accessories</a></li>';
    echo '<li><a href="' . get_category_link(get_cat_ID('Auto Parts Reviews')) . '" class="dropdown-item">Auto Parts Reviews</a></li>';
    echo '</ul>';
    echo '</li>';

    // Car Reviews dropdown - link parent to category archive if exists
    $car_reviews_url = engine_dynamo_resolve_category_link('car-reviews') ?: get_permalink(get_option('page_for_posts'));
    echo '<li class="nav-item dropdown">';
    echo '<a href="' . $car_reviews_url . '" class="nav-link">Car Reviews</a>';
    echo '<ul class="dropdown-menu">';
    echo '<li><a href="' . get_category_link(get_cat_ID('Toyota')) . '" class="dropdown-item">Toyota</a></li>';
    echo '<li><a href="' . get_category_link(get_cat_ID('Honda')) . '" class="dropdown-item">Honda</a></li>';
    echo '<li><a href="' . get_category_link(get_cat_ID('Budget Cars')) . '" class="dropdown-item">Budget Cars</a></li>';
    echo '</ul>';
    echo '</li>';
    echo '<li class="nav-item"><a href="' . home_url('/contact') . '" class="nav-link">Contact</a></li>';
    echo '</ul>';
}

// AJAX comment handler
function engine_dynamo_ajax_comment() {
    check_ajax_referer('engine_dynamo_nonce', 'nonce');

    // Support both comment_post_ID and post_id from different front-ends
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : (isset($_POST['comment_post_ID']) ? intval($_POST['comment_post_ID']) : 0);
    $parent  = isset($_POST['parent_id']) ? intval($_POST['parent_id']) : (isset($_POST['comment_parent']) ? intval($_POST['comment_parent']) : 0);

    $comment_author = isset($_POST['author']) ? sanitize_text_field($_POST['author']) : '';
    $comment_author_email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $comment_content = isset($_POST['comment']) ? sanitize_textarea_field($_POST['comment']) : '';

    if (empty($post_id) || empty($comment_content) || empty($comment_author) || empty($comment_author_email)) {
        wp_send_json_error(array('message' => 'Missing required fields.'));
    }

    $comment_data = array(
        'comment_post_ID' => $post_id,
        'comment_author' => $comment_author,
        'comment_author_email' => $comment_author_email,
        'comment_content' => $comment_content,
        'comment_type' => 'comment',
        'comment_parent' => $parent,
        'comment_approved' => 1,
    );

    $comment_id = wp_insert_comment($comment_data);

    if ($comment_id) {
        // Return minimal data front-end can use to render optimistic UI
        wp_send_json_success(array(
            'message' => 'Comment submitted successfully!',
            'comment_id' => $comment_id,
            'author' => esc_html($comment_author),
            'content' => wp_kses_post(nl2br(esc_html($comment_content))),
            'parent' => $parent,
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to submit comment.'));
    }
}
add_action('wp_ajax_engine_dynamo_comment', 'engine_dynamo_ajax_comment');
add_action('wp_ajax_nopriv_engine_dynamo_comment', 'engine_dynamo_ajax_comment');

// Contact form handler with rate limiting and spam protection
function engine_dynamo_handle_contact_form() {
    if (isset($_POST['contact_nonce']) && wp_verify_nonce($_POST['contact_nonce'], 'engine_dynamo_contact_form')) {
        // Rate limiting - max 3 submissions per IP per hour
        $ip = $_SERVER['REMOTE_ADDR'];
        $rate_limit_key = 'contact_form_' . md5($ip);
        $submissions = get_transient($rate_limit_key);
        
        if ($submissions && $submissions >= 3) {
            if (wp_doing_ajax()) {
                wp_send_json_error(array('message' => 'Too many attempts. Please try again later.'));
            } else {
                wp_redirect(add_query_arg('contact', 'rate_limit', wp_get_referer()));
                exit;
            }
        }
        
        // Add honeypot check
        if (!empty($_POST['website'])) { // Hidden honeypot field
            if (wp_doing_ajax()) {
                wp_send_json_error(array('message' => 'Invalid submission.'));
            } else {
                wp_redirect(add_query_arg('contact', 'spam_detected', wp_get_referer()));
                exit;
            }
        }
        
        // Increment rate limit counter
        if (!$submissions) {
            set_transient($rate_limit_key, 1, HOUR_IN_SECONDS);
        } else {
            set_transient($rate_limit_key, $submissions + 1, HOUR_IN_SECONDS);
        }
        
        $name = sanitize_text_field($_POST['contact_name']);
        $email = sanitize_email($_POST['contact_email']);
        $subject = sanitize_text_field($_POST['contact_subject']);
        $message = sanitize_textarea_field($_POST['contact_message']);
        
        // Validation
        if (empty($name) || empty($email) || empty($subject) || empty($message)) {
            wp_redirect(add_query_arg('contact', 'validation_error', wp_get_referer()));
            exit;
        }
        
        if (!is_email($email)) {
            wp_redirect(add_query_arg('contact', 'invalid_email', wp_get_referer()));
            exit;
        }
        
        // Spam protection - check for common spam patterns
        $spam_patterns = array('viagra', 'casino', 'loan', 'free money', 'click here');
        $content_to_check = strtolower($name . ' ' . $subject . ' ' . $message);
        
        foreach ($spam_patterns as $pattern) {
            if (strpos($content_to_check, $pattern) !== false) {
                wp_redirect(add_query_arg('contact', 'spam_detected', wp_get_referer()));
                exit;
            }
        }
        
        // Send email to info@enginedynamo.com
        $to = 'info@enginedynamo.com';
        $email_subject = '[ENGINE DYNAMO] Contact Form: ' . $subject;
        
        // Create HTML email template
        $email_message = engine_dynamo_create_contact_email_template($name, $email, $subject, $message);
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <noreply@enginedynamo.com>',
            'Reply-To: ' . $name . ' <' . $email . '>'
        );
        
        // Send email
        $mail_sent = wp_mail($to, $email_subject, $email_message, $headers);
        
        // Send auto-reply to user
        $auto_reply_subject = 'Thank you for contacting ENGINE DYNAMO';
        $auto_reply_message = engine_dynamo_create_auto_reply_template($name, $subject);
        $auto_reply_headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ENGINE DYNAMO <noreply@enginedynamo.com>'
        );
        
        wp_mail($email, $auto_reply_subject, $auto_reply_message, $auto_reply_headers);
        
        if ($mail_sent) {
            wp_redirect(add_query_arg('contact', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('contact', 'error', wp_get_referer()));
        }
        exit;
    }
}
add_action('init', 'engine_dynamo_handle_contact_form');

// AJAX contact form handler
function engine_dynamo_ajax_contact_form() {
    // Support both the global AJAX nonce and the contact form nonce
    if (isset($_POST['nonce'])) {
        check_ajax_referer('engine_dynamo_nonce', 'nonce');
    } elseif (isset($_POST['contact_nonce'])) {
        if (!wp_verify_nonce($_POST['contact_nonce'], 'engine_dynamo_contact_form')) {
            wp_send_json_error(array('message' => 'Invalid security token.'));
        }
    } else {
        wp_send_json_error(array('message' => 'Missing security token.'));
    }

    // Accept both the generic field names and the contact form prefixed names that
    // the front-end may post (e.g. contact_name, contact_email, ...). This avoids
    // mismatches between the page form and the AJAX handler.
    $name = sanitize_text_field(isset($_POST['name']) ? $_POST['name'] : (isset($_POST['contact_name']) ? $_POST['contact_name'] : ''));
    $email = sanitize_email(isset($_POST['email']) ? $_POST['email'] : (isset($_POST['contact_email']) ? $_POST['contact_email'] : ''));
    $subject = sanitize_text_field(isset($_POST['subject']) ? $_POST['subject'] : (isset($_POST['contact_subject']) ? $_POST['contact_subject'] : ''));
    $message = sanitize_textarea_field(isset($_POST['message']) ? $_POST['message'] : (isset($_POST['contact_message']) ? $_POST['contact_message'] : ''));
    
    $to = get_option('admin_email');
    $email_subject = 'Contact Form: ' . $subject;
    $email_message = "Name: $name\nEmail: $email\nSubject: $subject\n\nMessage:\n$message";
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    
    if (wp_mail($to, $email_subject, $email_message, $headers)) {
        wp_send_json_success(array('message' => 'Message sent successfully!'));
    } else {
        wp_send_json_error(array('message' => 'Failed to send message.'));
    }
}
add_action('wp_ajax_engine_dynamo_contact', 'engine_dynamo_ajax_contact_form');
add_action('wp_ajax_nopriv_engine_dynamo_contact', 'engine_dynamo_ajax_contact_form');

// Live search handler
function engine_dynamo_live_search() {
    check_ajax_referer('engine_dynamo_nonce', 'nonce');
    
    $search_term = sanitize_text_field($_POST['search_term']);
    
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 5,
        's' => $search_term,
        'post_status' => 'publish'
    );
    
    $search_results = new WP_Query($args);
    
    $results = array();
    if ($search_results->have_posts()) {
        while ($search_results->have_posts()) {
            $search_results->the_post();
            $results[] = array(
                'title' => get_the_title(),
                'url' => get_permalink(),
                'excerpt' => wp_trim_words(get_the_content(), 20)
            );
        }
    }
    
    wp_reset_postdata();
    wp_send_json_success($results);
}
add_action('wp_ajax_engine_dynamo_search', 'engine_dynamo_live_search');
add_action('wp_ajax_nopriv_engine_dynamo_search', 'engine_dynamo_live_search');

/**
 * Restrict front-end search queries to published posts/pages and exclude attachments.
 * This prevents empty searches from returning all content (including attachments).
 */
function engine_dynamo_filter_search_query( $query ) {
    if ( ! is_admin() && $query->is_search() && $query->is_main_query() ) {
        // Only search posts and pages, and only published items
        $query->set( 'post_type', array( 'post', 'page' ) );
        $query->set( 'post_status', 'publish' );
    }
}
add_action( 'pre_get_posts', 'engine_dynamo_filter_search_query' );

// Newsletter subscription handler with email verification using DB
function engine_dynamo_subscribe_newsletter() {
    // Check both nonce types to support both forms
    if (isset($_POST['newsletter_nonce'])) {
        check_ajax_referer('engine_dynamo_newsletter', 'newsletter_nonce');
    } else {
        check_ajax_referer('engine_dynamo_nonce', 'nonce');
    }

    $email = sanitize_email($_POST['email']);

    // Rate limiting for newsletter - max 3 attempts per IP per hour
    $ip = $_SERVER['REMOTE_ADDR'];
    $rate_limit_key = 'newsletter_' . md5($ip);
    $attempts = get_transient($rate_limit_key);

    if ($attempts && $attempts >= 3) {
        wp_send_json_error(array('message' => 'Too many attempts. Please try again later.'));
    }

    // Increment rate limit counter
    if (!$attempts) {
        set_transient($rate_limit_key, 1, HOUR_IN_SECONDS);
    } else {
        set_transient($rate_limit_key, $attempts + 1, HOUR_IN_SECONDS);
    }

    // Validation
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Please enter a valid email address.'));
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'newsletter_subscribers';

    // Check if email already exists
    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE email = %s", $email));
    if ($existing) {
        if ($existing->status === 'verified') {
            wp_send_json_error(array('message' => 'This email is already subscribed to our newsletter.'));
        } else {
            wp_send_json_error(array('message' => 'Please check your email and click the verification link to complete your subscription.'));
        }
    }

    // Generate verification token
    $verification_token = wp_generate_password(32, false);
    $verification_link = home_url('/?newsletter_verify=' . $verification_token);

    // Insert subscriber data into DB
    $result = $wpdb->insert(
        $table_name,
        array(
            'email' => $email,
            'status' => 'pending',
            'token' => $verification_token,
            'verification_sent' => current_time('mysql'),
            'subscribed_at' => current_time('mysql'),
            'ip_address' => $ip,
            'source' => 'popup'
        ),
        array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
    );

    if ($result === false) {
        // Log DB error to debug.log so server-side causes can be investigated
        if (!empty($wpdb->last_error)) {
            error_log('[Engine Dynamo] newsletter insert failed: ' . $wpdb->last_error);
        }

        // Provide a generic error to the client. When WP_DEBUG is enabled we include
        // a helpful hint to check server logs.
        $msg = 'Failed to save subscription. Please try again.';
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $msg .= ' (See server PHP error log for details.)';
        }

        wp_send_json_error(array('message' => $msg));
    }

    // Send verification email
    $verification_subject = 'Verify your ENGINE DYNAMO newsletter subscription';
    $verification_message = engine_dynamo_create_newsletter_verification_template($email, $verification_link);
    $verification_headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ENGINE DYNAMO <noreply@enginedynamo.com>'
    );

    $mail_sent = wp_mail($email, $verification_subject, $verification_message, $verification_headers);

    if ($mail_sent) {
        wp_send_json_success(array('message' => 'Please check your email and click the verification link to complete your subscription.'));
    } else {
        wp_send_json_error(array('message' => 'Failed to send verification email. Please try again.'));
    }
}
add_action('wp_ajax_engine_dynamo_newsletter', 'engine_dynamo_subscribe_newsletter');
add_action('wp_ajax_nopriv_engine_dynamo_newsletter', 'engine_dynamo_subscribe_newsletter');

// JavaScript error logging endpoint
function engine_dynamo_log_error() {
    // Accept the global AJAX nonce
    check_ajax_referer('engine_dynamo_nonce', 'nonce');

    $error = isset($_POST['error']) ? sanitize_text_field(wp_unslash($_POST['error'])) : '';
    $url = isset($_POST['url']) ? sanitize_text_field(wp_unslash($_POST['url'])) : '';
    $line = isset($_POST['line']) ? intval($_POST['line']) : 0;
    $column = isset($_POST['column']) ? intval($_POST['column']) : 0;
    $stack = isset($_POST['stack']) ? sanitize_textarea_field(wp_unslash($_POST['stack'])) : '';
    $extra = isset($_POST['browserInfo']) ? sanitize_text_field(wp_unslash($_POST['browserInfo'])) : '';

    $log_message = "[JS ERROR] " . $error . "\nURL: " . $url . "\nLine: " . $line . " Col: " . $column . "\nExtra: " . $extra . "\nStack:\n" . $stack;

    error_log($log_message);

    wp_send_json_success(array('message' => 'Logged'));
}
add_action('wp_ajax_engine_dynamo_log_error', 'engine_dynamo_log_error');
add_action('wp_ajax_nopriv_engine_dynamo_log_error', 'engine_dynamo_log_error');

// Rating system handler
function engine_dynamo_submit_rating() {
    check_ajax_referer('engine_dynamo_nonce', 'nonce');
    
    $post_id = intval($_POST['post_id']);
    $rating = intval($_POST['rating']);
    
    if ($rating < 1 || $rating > 5) {
        wp_send_json_error(array('message' => 'Invalid rating.'));
    }

    // Guard: one vote per logged-in user OR per IP per post (24h TTL)
    $user_id = get_current_user_id();
    $ip      = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
    $ip_hash = $ip ? md5($ip . 'engine_dynamo_salt') : '';

    $details = get_post_meta($post_id, '_post_rating_details', true);
    if (!is_array($details)) {
        $details = array(
            'user_ids' => array(), // user_id => timestamp
            'ip_hashes' => array(), // ip_hash => timestamp
        );
    }

    $now = time();
    $ttl = DAY_IN_SECONDS; // 24h window for IP-based votes

    // Clean expired IP entries
    foreach ($details['ip_hashes'] as $hash => $ts) {
        if ($ts + $ttl < $now) {
            unset($details['ip_hashes'][$hash]);
        }
    }

    if ($user_id && isset($details['user_ids'][$user_id])) {
        wp_send_json_error(array('message' => 'You already rated this post.'));
    }
    if (!$user_id && $ip_hash && isset($details['ip_hashes'][$ip_hash])) {
        wp_send_json_error(array('message' => 'You already rated this post.'));
    }

    // Update ratings
    $ratings = get_post_meta($post_id, '_post_ratings', true);
    if (!is_array($ratings)) {
        $ratings = array();
    }
    $ratings[] = $rating;
    update_post_meta($post_id, '_post_ratings', $ratings);

    // Update details
    if ($user_id) {
        $details['user_ids'][$user_id] = $now;
    } elseif ($ip_hash) {
        $details['ip_hashes'][$ip_hash] = $now;
    }
    update_post_meta($post_id, '_post_rating_details', $details);

    // Recalculate average
    $average_rating = array_sum($ratings) / count($ratings);
    update_post_meta($post_id, '_average_rating', $average_rating);

    wp_send_json_success(array('average' => round($average_rating, 1), 'count' => count($ratings)));
}
add_action('wp_ajax_engine_dynamo_rating', 'engine_dynamo_submit_rating');
add_action('wp_ajax_nopriv_engine_dynamo_rating', 'engine_dynamo_submit_rating');

// Rating system functionality is now handled directly in single.php template
function engine_dynamo_add_rating_system($content) {
    return $content; // No longer appending rating system to content
}
add_filter('the_content', 'engine_dynamo_add_rating_system');



// Add Schema.org markup
function engine_dynamo_add_schema_markup() {
    if (is_single()) {
        $schema = array(
            "@context" => "https://schema.org",
            "@type" => "BlogPosting",
            "headline" => get_the_title(),
            "image" => get_the_post_thumbnail_url(null, 'large'),
            "datePublished" => get_the_date('c'),
            "dateModified" => get_the_modified_date('c'),
            "author" => array(
                "@type" => "Person",
                "name" => get_the_author()
            ),
            "publisher" => array(
                "@type" => "Organization",
                "name" => get_bloginfo('name'),
                    "logo" => array(
                    "@type" => "ImageObject",
                    "url" => get_theme_file_uri('assets/images/logo.svg')
                )
            )
        );
        echo '<script type="application/ld+json">' . json_encode($schema) . '</script>';
    }
}
add_action('wp_head', 'engine_dynamo_add_schema_markup');

// Performance optimizations
function engine_dynamo_optimize_performance() {
    // Remove unnecessary WordPress features
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wp_shortlink_wp_head');
    
    // Add preconnect for performance
    add_filter('wp_resource_hints', function($hints, $relation_type) {
        if ('preconnect' === $relation_type) {
            $hints[] = ['href' => 'https://fonts.googleapis.com'];
            $hints[] = ['href' => 'https://fonts.gstatic.com', 'crossorigin' => 'anonymous'];
        }
        return $hints;
    }, 10, 2);
    
    // Disable emoji scripts
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    
    // Optimize database
    if (!wp_next_scheduled('engine_dynamo_optimize_db')) {
        wp_schedule_event(time(), 'weekly', 'engine_dynamo_optimize_db');
    }
}
add_action('init', 'engine_dynamo_optimize_performance');

// Database optimization
function engine_dynamo_optimize_database() {
    global $wpdb;
    
    // Clean up spam comments
    $wpdb->query("DELETE FROM {$wpdb->comments} WHERE comment_approved = 'spam'");
    
    // Clean up old revisions
    $wpdb->query("DELETE FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_date < DATE_SUB(NOW(), INTERVAL 30 DAY)");
    
    // Optimize tables
    $wpdb->query("OPTIMIZE TABLE {$wpdb->posts}");
    $wpdb->query("OPTIMIZE TABLE {$wpdb->comments}");
}
add_action('engine_dynamo_optimize_db', 'engine_dynamo_optimize_database');

// Security enhancements
function engine_dynamo_security_enhancements() {
    // Hide WordPress version
    remove_action('wp_head', 'wp_generator');
    
    // Disable file editing
    if (!defined('DISALLOW_FILE_EDIT')) {
        define('DISALLOW_FILE_EDIT', true);
    }
    
    // Remove login error messages
    add_filter('login_errors', function() {
        return 'Login failed. Please try again.';
    });
}
add_action('init', 'engine_dynamo_security_enhancements');

// Debug admin page and subscriber management
function engine_dynamo_admin_menu() {
    add_menu_page(
        'Engine Dynamo Debug',
        'ED Debug',
        'manage_options',
        'engine-dynamo-debug',
        'engine_dynamo_debug_page',
        'dashicons-chart-area',
        100
    );

    add_submenu_page(
        'engine-dynamo-debug',
        'Newsletter Subscribers',
        'Subscribers',
        'manage_options',
        'engine-dynamo-subscribers',
        'engine_dynamo_subscribers_page'
    );
}
add_action('admin_menu', 'engine_dynamo_admin_menu');

// Create subscribers table and run migrations
function engine_dynamo_install_db() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    // Create subscribers table
    $table_name = $wpdb->prefix . 'newsletter_subscribers';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        email varchar(100) NOT NULL,
        first_name varchar(50),
        last_name varchar(50),
        status enum('pending','verified','unsubscribed') DEFAULT 'pending',
        token varchar(32),
        verification_sent datetime,
        verified_at datetime,
        subscribed_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        ip_address varchar(45),
        source varchar(50),
        PRIMARY KEY  (id),
        UNIQUE KEY email (email),
        KEY status (status),
        KEY token (token)
    ) $charset_collate;";

    // Include WordPress upgrade functions
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Create error log table
    $table_name = $wpdb->prefix . 'js_error_logs';
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        error_message text NOT NULL,
        error_type varchar(50),
        url varchar(255),
        line int,
        column_num int,
        stack_trace text,
        browser_info text,
        user_id bigint(20),
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY error_type (error_type),
        KEY created_at (created_at)
    ) $charset_collate;";
    
    dbDelta($sql);

    // Set version
    update_option('engine_dynamo_db_version', '1.0');
}
register_activation_hook(__FILE__, 'engine_dynamo_install_db');

// Debug page content
function engine_dynamo_debug_page() {
    global $wpdb;

    // Get recent JS errors
    $errors = $wpdb->get_results("
        SELECT *
        FROM {$wpdb->prefix}js_error_logs
        ORDER BY created_at DESC
        LIMIT 100
    ");

    // Get error log file content
    $log_file = WP_CONTENT_DIR . '/debug.log';
    $log_content = '';
    if (file_exists($log_file)) {
        $log_content = file_get_contents($log_file);
        $log_lines = array_filter(array_map('trim', explode("\n", $log_content)));
        $log_lines = array_slice($log_lines, -100); // Last 100 lines
        $log_content = implode("\n", $log_lines);
    }
    ?>
    <div class="wrap">
        <h1>Engine Dynamo Debug</h1>
        
        <div class="card">
            <h2>Recent JavaScript Errors</h2>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Type</th>
                        <th>Message</th>
                        <th>URL</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($errors as $error): ?>
                    <tr>
                        <td><?php echo esc_html(date('Y-m-d H:i:s', strtotime($error->created_at))); ?></td>
                        <td><?php echo esc_html($error->error_type); ?></td>
                        <td><?php echo esc_html($error->error_message); ?></td>
                        <td><?php echo esc_html($error->url); ?></td>
                        <td>
                            <details>
                                <summary>Stack</summary>
                                <pre><?php echo esc_html($error->stack_trace); ?></pre>
                            </details>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h2>PHP Error Log (Last 100 Lines)</h2>
            <pre style="background: #f8f9fa; padding: 15px; max-height: 400px; overflow: auto;">
                <?php echo esc_html($log_content); ?>
            </pre>
        </div>
    </div>
    <?php
}

// Subscribers page content
function engine_dynamo_subscribers_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'newsletter_subscribers';

    // Handle bulk actions
    if (isset($_POST['action']) && isset($_POST['subscriber'])) {
        $action = sanitize_text_field($_POST['action']);
        $ids = array_map('intval', $_POST['subscriber']);
        
        switch ($action) {
            case 'delete':
                $wpdb->query("DELETE FROM $table_name WHERE id IN (" . implode(',', $ids) . ")");
                break;
            case 'verify':
                $wpdb->query($wpdb->prepare(
                    "UPDATE $table_name SET status = 'verified', verified_at = %s WHERE id IN (" . implode(',', $ids) . ")",
                    current_time('mysql')
                ));
                break;
            case 'unsubscribe':
                $wpdb->query($wpdb->prepare(
                    "UPDATE $table_name SET status = 'unsubscribed', updated_at = %s WHERE id IN (" . implode(',', $ids) . ")",
                    current_time('mysql')
                ));
                break;
        }
    }

    // Get subscribers with pagination
    $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;
    $offset = ($page - 1) * $per_page;
    
    $where = array("1=1");
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
    if ($search) {
        $where[] = $wpdb->prepare("(email LIKE %s OR first_name LIKE %s OR last_name LIKE %s)", 
            "%$search%", "%$search%", "%$search%");
    }
    
    $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
    if ($status_filter) {
        $where[] = $wpdb->prepare("status = %s", $status_filter);
    }

    $where = implode(" AND ", $where);
    
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE $where");
    $subscribers = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE $where ORDER BY subscribed_at DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    // Show export button if we have subscribers
    if ($total > 0) {
        if (isset($_POST['export'])) {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment;filename=newsletter-subscribers.csv');
            $fp = fopen('php://output', 'w');
            fputcsv($fp, array('Email', 'First Name', 'Last Name', 'Status', 'Subscribed', 'Verified'));
            
            $all_subscribers = $wpdb->get_results("SELECT * FROM $table_name ORDER BY subscribed_at DESC");
            foreach ($all_subscribers as $sub) {
                fputcsv($fp, array(
                    $sub->email,
                    $sub->first_name,
                    $sub->last_name,
                    $sub->status,
                    $sub->subscribed_at,
                    $sub->verified_at
                ));
            }
            fclose($fp);
            exit;
        }
    }
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Newsletter Subscribers</h1>
        
        <form method="get">
            <input type="hidden" name="page" value="engine-dynamo-subscribers" />
            <p class="search-box">
                <label class="screen-reader-text">Search Subscribers:</label>
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" />
                <select name="status">
                    <option value="">All Status</option>
                    <option value="pending" <?php selected($status_filter, 'pending'); ?>>Pending</option>
                    <option value="verified" <?php selected($status_filter, 'verified'); ?>>Verified</option>
                    <option value="unsubscribed" <?php selected($status_filter, 'unsubscribed'); ?>>Unsubscribed</option>
                </select>
                <input type="submit" class="button" value="Search Subscribers" />
            </p>
        </form>

        <form method="post">
            <?php if ($total > 0): ?>
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <select name="action">
                        <option value="">Bulk Actions</option>
                        <option value="delete">Delete</option>
                        <option value="verify">Mark as Verified</option>
                        <option value="unsubscribe">Unsubscribe</option>
                    </select>
                    <input type="submit" class="button action" value="Apply" />
                </div>
                <div class="alignright">
                    <input type="submit" name="export" class="button" value="Export CSV" />
                </div>
            </div>
            <?php endif; ?>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <input type="checkbox" />
                        </td>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Subscribed</th>
                        <th>Verified</th>
                        <th>Source</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($subscribers)): ?>
                    <tr>
                        <td colspan="7">No subscribers found.</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($subscribers as $sub): ?>
                    <tr>
                        <th scope="row" class="check-column">
                            <input type="checkbox" name="subscriber[]" value="<?php echo esc_attr($sub->id); ?>" />
                        </th>
                        <td><?php echo esc_html($sub->email); ?></td>
                        <td>
                            <?php
                            $name_parts = array_filter(array($sub->first_name, $sub->last_name));
                            echo esc_html(implode(' ', $name_parts));
                            ?>
                        </td>
                        <td><?php echo esc_html($sub->status); ?></td>
                        <td><?php echo esc_html(date('Y-m-d H:i', strtotime($sub->subscribed_at))); ?></td>
                        <td>
                            <?php
                            if ($sub->verified_at) {
                                echo esc_html(date('Y-m-d H:i', strtotime($sub->verified_at)));
                            } else {
                                echo '—';
                            }
                            ?>
                        </td>
                        <td><?php echo esc_html($sub->source); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>

        <?php
        $total_pages = ceil($total / $per_page);
        if ($total_pages > 1) {
            echo '<div class="tablenav bottom"><div class="tablenav-pages">';
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
                'total' => $total_pages,
                'current' => $page
            ));
            echo '</div></div>';
        }
        ?>
    </div>
    <?php
}

// Migration: Move subscribers from options to DB
function engine_dynamo_migrate_subscribers() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'newsletter_subscribers';
    
    // Get all subscribers from options
    $subscribers = get_option('newsletter_subscribers', array());
    if (!empty($subscribers)) {
        foreach ($subscribers as $email_hash => $data) {
            // Skip if already migrated
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $table_name WHERE email = %s",
                $data['email']
            ));
            
            if (!$exists) {
                $wpdb->insert($table_name, array(
                    'email' => $data['email'],
                    'status' => !empty($data['verified']) ? 'verified' : 'pending',
                    'token' => $data['token'],
                    'verified_at' => !empty($data['verified_at']) ? $data['verified_at'] : null,
                    'subscribed_at' => $data['subscribed_at'],
                    'ip_address' => !empty($data['ip']) ? $data['ip'] : null,
                    'source' => 'migration'
                ));
            }
        }
        
        // Backup and delete old option
        update_option('newsletter_subscribers_backup', $subscribers);
        delete_option('newsletter_subscribers');
    }
}

// Install/upgrade check
function engine_dynamo_check_version() {
    if (get_option('engine_dynamo_db_version') != '1.0') {
        engine_dynamo_install_db();
        engine_dynamo_migrate_subscribers();
    }
}
add_action('plugins_loaded', 'engine_dynamo_check_version');

// Create newsletter subscribers table on theme activation
function engine_dynamo_create_subscribers_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'newsletter_subscribers';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        email varchar(100) NOT NULL,
        status enum('pending','verified','unsubscribed') DEFAULT 'pending',
        token varchar(32),
        verification_sent datetime DEFAULT NULL,
        verified_at datetime DEFAULT NULL,
        subscribed_at datetime DEFAULT CURRENT_TIMESTAMP,
        ip_address varchar(45),
        source varchar(50),
        PRIMARY KEY  (id),
        UNIQUE KEY email (email),
        KEY status (status)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
add_action('after_switch_theme', 'engine_dynamo_create_subscribers_table');

// Configure WordPress mail settings
function engine_dynamo_configure_smtp($phpmailer) {
    // Configure SMTP settings
    $phpmailer->isSMTP();
    $phpmailer->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com'; // Default to Gmail SMTP
    $phpmailer->SMTPAuth = true;
    $phpmailer->Port = defined('SMTP_PORT') ? SMTP_PORT : 587;
    $phpmailer->Username = defined('SMTP_USER') ? SMTP_USER : get_option('admin_email');
    $phpmailer->Password = defined('SMTP_PASS') ? SMTP_PASS : ''; // Set this in wp-config.php
    $phpmailer->SMTPSecure = 'tls';
    $phpmailer->From = $phpmailer->Username;
    $phpmailer->FromName = get_bloginfo('name');
    
    // Debug mode - uncomment these lines if you need to troubleshoot
    // $phpmailer->SMTPDebug = 2;
    // $phpmailer->Debugoutput = 'error_log';
    
    // Set timeout
    $phpmailer->Timeout = 30;
    
    // Set keep-alive
    $phpmailer->SMTPKeepAlive = true;
}
add_action('phpmailer_init', 'engine_dynamo_configure_smtp');

// AJAX handler for logging JavaScript errors
function engine_dynamo_log_js_error() {
    check_ajax_referer('ed_ajax_nonce', 'nonce');
    
    $error_data = json_decode(stripslashes($_POST['error']), true);
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'js_error_logs';
    
    $wpdb->insert(
        $table_name,
        array(
            'error_message' => $error_data['error_message'],
            'error_type' => $error_data['error_type'],
            'url' => $error_data['url'],
            'line' => $error_data['line'],
            'column_num' => $error_data['column_num'],
            'stack_trace' => $error_data['stack_trace'],
            'browser_info' => $error_data['browser_info'],
            'user_id' => get_current_user_id()
        ),
        array(
            '%s', // error_message
            '%s', // error_type
            '%s', // url
            '%d', // line
            '%d', // column_num
            '%s', // stack_trace
            '%s', // browser_info
            '%d'  // user_id
        )
    );
    
    wp_send_json_success();
}
add_action('wp_ajax_log_js_error', 'engine_dynamo_log_js_error');
add_action('wp_ajax_nopriv_log_js_error', 'engine_dynamo_log_js_error');

// Add nonce to JavaScript
// NOTE: Removed duplicate/conflicting nonce/localization helper. The main
// localization for front-end AJAX is handled in engine_dynamo_scripts() where
// `engine_dynamo_ajax` is set. Keeping multiple localized objects with
// different nonce names caused mismatches and 403s in some environments.

// WooCommerce support
function engine_dynamo_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'engine_dynamo_woocommerce_support');

// Add URL rewriting for custom pages
function engine_dynamo_add_rewrite_rules() {
    // Maintenance Tips
    add_rewrite_rule('^maintenance-tips/engine-care/?$', 'index.php?maintenance_page=engine-care', 'top');
    add_rewrite_rule('^maintenance-tips/tire-wheel-care/?$', 'index.php?maintenance_page=tire-wheel-care', 'top');
    add_rewrite_rule('^maintenance-tips/diy-fixes/?$', 'index.php?maintenance_page=diy-fixes', 'top');
    add_rewrite_rule('^maintenance-tips/cleaning-detailing/?$', 'index.php?maintenance_page=cleaning-detailing', 'top');
    
    // Tires & Parts
    add_rewrite_rule('^tires-parts/best-tire-brands/?$', 'index.php?tires_parts_page=best-tire-brands', 'top');
    add_rewrite_rule('^tires-parts/car-accessories/?$', 'index.php?tires_parts_page=car-accessories', 'top');
    add_rewrite_rule('^tires-parts/auto-parts-reviews/?$', 'index.php?tires_parts_page=auto-parts-reviews', 'top');
    
    // Car Reviews
    add_rewrite_rule('^car-reviews/toyota/?$', 'index.php?car_review_page=toyota', 'top');
    add_rewrite_rule('^car-reviews/honda/?$', 'index.php?car_review_page=honda', 'top');
    add_rewrite_rule('^car-reviews/budget-cars/?$', 'index.php?car_review_page=budget-cars', 'top');
}
add_action('init', 'engine_dynamo_add_rewrite_rules');

// Add query vars
function engine_dynamo_add_query_vars($vars) {
    $vars[] = 'maintenance_page';
    $vars[] = 'tires_parts_page';
    $vars[] = 'car_review_page';
    return $vars;
}
add_filter('query_vars', 'engine_dynamo_add_query_vars');

// Handle custom page templates - DISABLED (templates don't exist)
/*
function engine_dynamo_template_redirect() {
    if (get_query_var('maintenance_page')) {
        include(get_template_directory() . '/page-maintenance.php');
        exit;
    }
    if (get_query_var('tires_parts_page')) {
        include(get_template_directory() . '/page-tires-parts.php');
        exit;
    }
    if (get_query_var('car_review_page')) {
        include(get_template_directory() . '/page-car-reviews.php');
        exit;
    }
}
add_action('template_redirect', 'engine_dynamo_template_redirect');
*/

// Flush rewrite rules on theme activation
function engine_dynamo_flush_rewrite_rules() {
    engine_dynamo_add_rewrite_rules();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'engine_dynamo_flush_rewrite_rules');

// Email template functions
function engine_dynamo_create_contact_email_template($name, $email, $subject, $message) {
    $template = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2B6EF2; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #2B6EF2; }
            .footer { background: #0A0F1C; color: white; padding: 15px; text-align: center; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>ENGINE DYNAMO - New Contact Form Submission</h2>
            </div>
            <div class="content">
                <div class="field">
                    <span class="label">Name:</span> ' . esc_html($name) . '
                </div>
                <div class="field">
                    <span class="label">Email:</span> ' . esc_html($email) . '
                </div>
                <div class="field">
                    <span class="label">Subject:</span> ' . esc_html($subject) . '
                </div>
                <div class="field">
                    <span class="label">Message:</span><br>
                    ' . nl2br(esc_html($message)) . '
                </div>
            </div>
            <div class="footer">
                <p>This email was sent from the ENGINE DYNAMO contact form.</p>
                <p>Reply directly to this email to respond to the customer.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return $template;
}

function engine_dynamo_create_auto_reply_template($name, $subject) {
    $template = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2B6EF2; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .footer { background: #0A0F1C; color: white; padding: 15px; text-align: center; font-size: 12px; }
            .btn { display: inline-block; background: #2B6EF2; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Thank You for Contacting ENGINE DYNAMO!</h2>
            </div>
            <div class="content">
                <p>Dear ' . esc_html($name) . ',</p>
                <p>Thank you for reaching out to us regarding: <strong>' . esc_html($subject) . '</strong></p>
                <p>We have received your message and our team will review it carefully. We typically respond within 24 hours during business days.</p>
                <p>In the meantime, feel free to explore our latest automotive content:</p>
                <a href="' . home_url('/') . '" class="btn">Visit Our Website</a>
                <p>Best regards,<br>The ENGINE DYNAMO Team</p>
            </div>
            <div class="footer">
                <p>ENGINE DYNAMO - Your Ultimate Automotive Resource</p>
                <p>This is an automated response. Please do not reply to this email.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return $template;
}

function engine_dynamo_create_newsletter_verification_template($email, $verification_link) {
    $template = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2B6EF2; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .footer { background: #0A0F1C; color: white; padding: 15px; text-align: center; font-size: 12px; }
            .btn { display: inline-block; background: #E63946; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Welcome to ENGINE DYNAMO Newsletter!</h2>
            </div>
            <div class="content">
                <p>Thank you for subscribing to our newsletter!</p>
                <p>To complete your subscription and start receiving our latest automotive news, tips, and exclusive content, please verify your email address by clicking the button below:</p>
                <div style="text-align: center;">
                    <a href="' . esc_url($verification_link) . '" class="btn">Verify My Email Address</a>
                </div>
                <p>If the button doesn\'t work, you can copy and paste this link into your browser:</p>
                <p style="word-break: break-all; background: #eee; padding: 10px; border-radius: 5px;">' . esc_url($verification_link) . '</p>
                <p><strong>What you\'ll get:</strong></p>
                <ul>
                    <li>Latest automotive news and reviews</li>
                    <li>Expert maintenance tips and DIY guides</li>
                    <li>Exclusive deals on car parts and accessories</li>
                    <li>Early access to new content</li>
                </ul>
                <p>If you didn\'t subscribe to our newsletter, you can safely ignore this email.</p>
            </div>
            <div class="footer">
                <p>ENGINE DYNAMO - Your Ultimate Automotive Resource</p>
                <p>This verification link will expire in 24 hours.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return $template;
}

// Newsletter verification handler using DB
function engine_dynamo_handle_newsletter_verification() {
    if (isset($_GET['newsletter_verify'])) {
        $token = sanitize_text_field($_GET['newsletter_verify']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'newsletter_subscribers';

        // Find subscriber by token
        $subscriber = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE token = %s AND status = 'pending'",
            $token
        ));

        if ($subscriber) {
            // Update status to verified
            $result = $wpdb->update(
                $table_name,
                array(
                    'status' => 'verified',
                    'verified_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql')
                ),
                array('id' => $subscriber->id),
                array('%s', '%s', '%s'),
                array('%d')
            );

            if ($result !== false) {
                wp_redirect(home_url('/?newsletter=verified'));
            } else {
                wp_redirect(home_url('/?newsletter=error'));
            }
        } else {
            wp_redirect(home_url('/?newsletter=invalid'));
        }
        exit;
    }
}
add_action('init', 'engine_dynamo_handle_newsletter_verification');

// Add newsletter verification messages to frontend
function engine_dynamo_add_newsletter_messages() {
    if (isset($_GET['newsletter'])) {
        $message_type = $_GET['newsletter'];
        $message = '';

        switch ($message_type) {
            case 'verified':
                $message = '<div class="newsletter-verification-message success">Thank you! Your email has been verified. You are now subscribed to our newsletter.</div>';
                break;
            case 'invalid':
                $message = '<div class="newsletter-verification-message error">Invalid verification link. Please try subscribing again.</div>';
                break;
        }

        if ($message) {
            echo '<div class="newsletter-verification-container" style="position: fixed; top: 100px; left: 50%; transform: translateX(-50%); z-index: 9999; max-width: 500px; padding: 0 20px;">' . $message . '</div>';
            echo '<script>
                setTimeout(function() {
                    document.querySelector(".newsletter-verification-container").style.opacity = "0";
                    setTimeout(function() {
                        document.querySelector(".newsletter-verification-container").remove();
                    }, 500);
                }, 5000);
            </script>';
        }
    }
}
add_action('wp_footer', 'engine_dynamo_add_newsletter_messages');

/**
 * Insert demo comments for visual testing (runs once)
 * This will add a couple of parent comments and replies to the first published post if none exist.
 */
function engine_dynamo_insert_demo_comments() {
    if (get_option('engine_dynamo_demo_comments_done')) {
        return;
    }

    // Find a post to attach demo comments to
    $posts = get_posts(array('post_type' => 'post', 'numberposts' => 1, 'post_status' => 'publish'));
    if (empty($posts)) return;

    $post_id = $posts[0]->ID;

    // If post already has comments, skip
    $comments = get_comments(array('post_id' => $post_id, 'count' => true));
    if ($comments > 0) {
        update_option('engine_dynamo_demo_comments_done', 1);
        return;
    }

    // Insert parent comments
    $parent1 = wp_insert_comment(array(
        'comment_post_ID' => $post_id,
        'comment_author' => 'Demo User',
        'comment_author_email' => 'demo1@example.com',
        'comment_content' => 'This is a demo parent comment. It shows how comments look on this theme.',
        'comment_approved' => 1,
        'comment_date' => current_time('mysql')
    ));

    $parent2 = wp_insert_comment(array(
        'comment_post_ID' => $post_id,
        'comment_author' => 'Another Demo',
        'comment_author_email' => 'demo2@example.com',
        'comment_content' => 'Another parent comment for testing replies.',
        'comment_approved' => 1,
        'comment_date' => current_time('mysql')
    ));

    // Insert replies
    if ($parent1) {
        wp_insert_comment(array(
            'comment_post_ID' => $post_id,
            'comment_parent' => $parent1,
            'comment_author' => 'Reply User',
            'comment_author_email' => 'reply1@example.com',
            'comment_content' => 'This is a reply to the first demo comment.',
            'comment_approved' => 1,
            'comment_date' => current_time('mysql')
        ));

        wp_insert_comment(array(
            'comment_post_ID' => $post_id,
            'comment_parent' => $parent1,
            'comment_author' => 'Second Replier',
            'comment_author_email' => 'reply2@example.com',
            'comment_content' => 'Another reply to the first comment for demonstrating threading.',
            'comment_approved' => 1,
            'comment_date' => current_time('mysql')
        ));
    }

    update_option('engine_dynamo_demo_comments_done', 1);
}
add_action('init', 'engine_dynamo_insert_demo_comments');

// Reading time calculation function
function engine_dynamo_get_reading_time($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }

    // Check for custom reading time override
    $custom_reading_time = get_post_meta($post_id, 'reading_time_override', true);
    if (!empty($custom_reading_time) && is_numeric($custom_reading_time)) {
        return intval($custom_reading_time);
    }

    // Calculate based on word count (200 words per minute)
    $content = get_post_field('post_content', $post_id);
    $word_count = str_word_count(strip_tags($content));
    $reading_time = ceil($word_count / 200);

    // Minimum reading time of 1 minute
    return max(1, $reading_time);
}

// Display reading time
function engine_dynamo_display_reading_time($post_id = null) {
    $reading_time = engine_dynamo_get_reading_time($post_id);
    return $reading_time . ' min read';
}

// Prevent redirect to single post when category or blog archive has only one post
add_action('template_redirect', 'engine_dynamo_prevent_single_post_redirect');
function engine_dynamo_prevent_single_post_redirect() {
    // Prevent for categories
    if (is_category()) {
        $category = get_queried_object();
        $category_ids = array($category->term_id);
        $descendants = engine_dynamo_get_all_category_descendants($category->term_id);
        $category_ids = array_merge($category_ids, $descendants);
        $post_count = 0;
        foreach ($category_ids as $cat_id) {
            $cat = get_category($cat_id);
            $post_count += $cat->count;
        }
        if ($post_count == 1) {
            remove_action('template_redirect', 'redirect_canonical');
        }
    }
    // Prevent for blog archive
    if (is_home() && !is_paged()) {
        global $wp_query;
        if ($wp_query->post_count == 1) {
            remove_action('template_redirect', 'redirect_canonical');
        }
    }
}

// Recursive function to get all category descendants
function engine_dynamo_get_all_category_descendants($category_id, &$descendants = array()) {
    $children = get_categories(array(
        'parent' => $category_id,
        'hide_empty' => false,
        'fields' => 'ids'
    ));

    foreach ($children as $child_id) {
        $descendants[] = $child_id;
        // Recursively get children of this child
        engine_dynamo_get_all_category_descendants($child_id, $descendants);
    }

    return $descendants;
}

// Custom comment callback function
function engine_dynamo_comment_callback($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    ?>
    <li <?php comment_class('comment'); ?> id="comment-<?php comment_ID(); ?>">
        <article class="comment-body">
            <div class="comment-author">
                <?php echo get_avatar($comment, 60); ?>
                <div class="comment-meta">
                    <h4 class="comment-name"><?php comment_author_link(); ?></h4>
                    <time class="comment-time" datetime="<?php comment_time('c'); ?>">
                        <?php printf(__('%1$s at %2$s', 'engine-dynamo'), get_comment_date(), get_comment_time()); ?>
                    </time>
                </div>
            </div>
            <div class="comment-content">
                <?php comment_text(); ?>
            </div>
            <div class="comment-actions">
                <?php 
                comment_reply_link(array_merge($args, array(
                    'depth' => $depth,
                    'max_depth' => $args['max_depth'],
                    'reply_text' => __('Reply', 'engine-dynamo'),
                    'before' => '<span class="reply-link">',
                    'after' => '</span>'
                ))); 
                ?>
            </div>
        </article>
    <?php
}


// NOTE: Email verification for comments has been removed to allow immediate posting and AJAX replies.
// The previous verification handlers were intentionally disabled to meet the project's requirement.


// === STEP 2: CONTACT FORM (Manual Email to Admin) ===
function ed_handle_contact_form() {
    if (isset($_POST['ed_send_contact'])) {
        if (!wp_verify_nonce($_POST['ed_contact_nonce'], 'ed_contact_form')) {
            wp_die('Nonce verification failed. Reload the page.');
        }

        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $message = sanitize_textarea_field($_POST['message']);

        $to = 'info@enginedynamo.com';
        $subject = "New Contact Message from $name";
        $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
        $headers = ['Reply-To: ' . $email];

        if (wp_mail($to, $subject, $body, $headers)) {
            echo '<p>✅ Message sent successfully!</p>';
        } else {
            echo '<p>❌ Failed to send message. Check mail configuration.</p>';
        }
    }
}
add_action('wp', 'ed_handle_contact_form');


// === STEP 3: NEWSLETTER (Manual Signup + Verification + DB Storage) ===
function ed_newsletter_handler() {
    if (isset($_POST['ed_subscribe_btn'])) {
        if (!wp_verify_nonce($_POST['ed_sub_nonce'], 'ed_subscribe')) {
            wp_die('Nonce failed 💀');
        }

        global $wpdb;
        $table = $wpdb->prefix . 'newsletter_subs';
        $email = sanitize_email($_POST['ed_sub_email']);
        $key = md5($email . time());

        // Create table if not exists
        $wpdb->query("CREATE TABLE IF NOT EXISTS $table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            verified BOOLEAN DEFAULT 0,
            verify_key VARCHAR(64)
        )");

        // Insert unverified user
        $wpdb->insert($table, ['email' => $email, 'verify_key' => $key]);

        // Send verification mail
        $verify_link = add_query_arg(['verify_sub' => $key], site_url());
        wp_mail($email, 'Verify your subscription', "Click to confirm: $verify_link");

        echo "<p>📨 Please check your inbox to verify subscription.</p>";
    }

    // Handle verification
    if (isset($_GET['verify_sub'])) {
        global $wpdb;
        $table = $wpdb->prefix . 'newsletter_subs';
        $key = sanitize_text_field($_GET['verify_sub']);

        $sub = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE verify_key=%s", $key));
        if ($sub) {
            $wpdb->update($table, ['verified' => 1], ['verify_key' => $key]);
            echo "<h2>✅ Subscription verified! Welcome aboard!</h2>";
        } else {
            echo "<h2>❌ Invalid or expired link.</h2>";
        }
    }
}
add_action('wp', 'ed_newsletter_handler');


// === STEP 4: SMTP (so mail doesn’t go to spam) ===
// (Override mail settings if needed)
add_action('phpmailer_init', function($phpmailer) {
    if (defined('WP_MAIL_SMTP') && WP_MAIL_SMTP) {
        $phpmailer->isSMTP();
        $phpmailer->Host = defined('SMTP_HOST') ? SMTP_HOST : '';
        $phpmailer->SMTPAuth = true;
        $phpmailer->Port = defined('SMTP_PORT') ? SMTP_PORT : 587;
        $phpmailer->Username = defined('SMTP_USER') ? SMTP_USER : '';
        $phpmailer->Password = defined('SMTP_PASS') ? SMTP_PASS : '';
        $phpmailer->SMTPSecure = defined('SMTP_SECURE') ? SMTP_SECURE : 'tls';
        $phpmailer->From = defined('SMTP_USER') ? SMTP_USER : $phpmailer->From;
        $phpmailer->FromName = 'Engine Dynamo';
    }
});


