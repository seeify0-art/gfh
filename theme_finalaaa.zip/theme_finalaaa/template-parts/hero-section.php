<?php
/**
 * Template part for displaying hero section
 */
?>
<section class="hero-section">
    <div class="hero-content">
        <h1 class="engine-dynamo">
            <span class="engine">ENGINE</span><span class="dynamo">DYNAMO</span>
        </h1>
        <p class="hero-tagline">
            Premium automotive writing — deep reviews, real tips.
        </p>
        <p class="hero-description">
            High-performance guides, buying advice, and maintenance tips — delivered with cinematic design and modern interaction.
        </p>
        <div class="hero-buttons">
            <a href="/blog" class="btn btn-primary">Latest Posts</a>
            <a href="/about" class="btn btn-outline">About</a>
        </div>
    </div>
</section>