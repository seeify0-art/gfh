<?php
/**
 * Social share buttons template
 */

$post_url = urlencode(get_permalink());
$post_title = urlencode(get_the_title());
?>

<div class="share-this-article">
    <h4>Share this article</h4>
    <div class="share-options">
        <!-- Facebook -->
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $post_url; ?>" 
           target="_blank" 
           rel="noopener"
           class="share-btn facebook">
            <i class="fab fa-facebook"></i>
            Share
        </a>

        <!-- WhatsApp -->
        <a href="https://api.whatsapp.com/send?text=<?php echo $post_title . '%20' . $post_url; ?>" 
           target="_blank" 
           rel="noopener"
           class="share-btn whatsapp">
            <i class="fab fa-whatsapp"></i>
            Share
        </a>

        <!-- Email -->
        <a href="mailto:?subject=<?php echo $post_title; ?>&body=Check out this article: <?php echo $post_url; ?>" 
           class="share-btn email">
            <i class="fas fa-envelope"></i>
            Email
        </a>

        <!-- Copy Link -->
        <button class="share-btn copy-link" 
                data-url="<?php echo get_permalink(); ?>">
            <i class="fas fa-link"></i>
            <span>Copy Link</span>
        </button>
    </div>
</div>

