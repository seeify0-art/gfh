<?php
/**
 * The template for displaying blog posts
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <!-- Blog Header -->
        <header class="page-header">
            <?php
            $category_filter = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
            if ($category_filter) {
                $category = get_category_by_slug($category_filter);
                if ($category) {
                    echo '<h1 class="page-title">' . esc_html($category->name) . '</h1>';
                    echo '<p class="page-description">' . esc_html($category->description ?: 'Posts in ' . $category->name) . '</p>';
                } else {
                    echo '<h1 class="page-title">Category Not Found</h1>';
                    echo '<p class="page-description">The requested category does not exist.</p>';
                }
            } else {
                echo '<h1 class="page-title">Blog</h1>';
                echo '<p class="page-description">Latest automotive news, reviews, and maintenance tips</p>';
            }
            ?>
        </header>

        <!-- Blog Layout -->
        <div class="blog-layout">
            
            <!-- Main Content -->
            <div class="blog-content">
                <div class="posts-grid">
                    <?php
                    // Modify query if category filter is present
                    if ($category_filter) {
                        $category = get_category_by_slug($category_filter);
                        if ($category) {
                            query_posts(array(
                                'cat' => $category->term_id,
                                'paged' => get_query_var('paged') ? get_query_var('paged') : 1
                            ));
                        }
                    }
                    
                    if (have_posts()) :
                        while (have_posts()) : the_post();
                    ?>
                        <article class="post-card">
                            <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <?php the_post_thumbnail('article-thumbnail'); ?>
                                    <?php else : ?>
                                        <div class="placeholder-image">
                                            <span class="placeholder-icon">🚗</span>
                                            <span class="placeholder-text">Automotive</span>
                                        </div>
                                    <?php endif; ?>
                                </a>
                            </div>
                            
                            <div class="post-content">
                                <div class="post-meta">
                                    <span class="post-date"><?php echo get_the_date(); ?></span>
                                    <span class="post-category"><?php the_category(', '); ?></span>
                                    <span class="reading-time"><?php echo engine_dynamo_display_reading_time(); ?></span>
                                </div>
                                
                                <h2 class="post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                
                                <div class="post-excerpt">
                                    <?php echo wp_trim_words(get_the_content(), 20, '...'); ?>
                                </div>
                                
                                <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                            </div>
                        </article>
                    <?php
                        endwhile;
                        
                        // Pagination
                        the_posts_pagination(array(
                            'prev_text' => '← Previous',
                            'next_text' => 'Next →',
                        ));
                        
                    else :
                    ?>
                        <div class="no-posts">
                            <div class="no-posts-icon">📝</div>
                            <h2>No Posts Found</h2>
                            <p>We're working on creating amazing automotive content for you. Check back soon!</p>
                            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">Go Home</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="sidebar">
                <?php get_sidebar(); ?>
            </div>
            
        </div>
        
    </div>
</main>

<?php
// Reset query if we modified it
if ($category_filter) {
    wp_reset_query();
}
get_footer();