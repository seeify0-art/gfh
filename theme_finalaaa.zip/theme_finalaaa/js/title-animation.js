document.addEventListener("DOMContentLoaded", function() {
    // Make sure elements exist
    const title = document.querySelector('.engine-dynamo');
    if (!title) return;

    // Set initial state
    gsap.set(".engine-dynamo", {
        opacity: 0,
        x: -100,
        immediateRender: true
    });

    // Create timeline
    const tl = gsap.timeline({
        defaults: { ease: "power3.out" }
    });

    // Add animations
    tl.to(".engine-dynamo", {
        opacity: 1,
        x: 0,
        duration: 1.2,
        delay: 0.5
    });
    
    // Animate hero buttons in after title (if present)
    if (document.querySelector('.hero-buttons')) {
        gsap.set('.hero-buttons', { opacity: 0, y: 20 });
        tl.to('.hero-buttons', { opacity: 1, y: 0, duration: 0.8 }, '-=0.6');
    }
});