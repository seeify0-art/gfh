/**
 * Engine Dynamo Theme JavaScript
 * Modern, animated automotive blog theme
 */

(function($) {
    'use strict';

    // Show loading screen immediately when script loads (robust injection)
    if (!$('#loading-screen').length) {
        // Safe theme URL fallback (tries localized object first, then infers from stylesheet href)
        const themeUrl = (typeof engine_dynamo_ajax !== 'undefined' && engine_dynamo_ajax.theme_url) ? engine_dynamo_ajax.theme_url : (function() {
            try {
                const link = document.querySelector('link[rel="stylesheet"]');
                if (link && link.href) return link.href.replace(/\/[^\/]*style\.css.*$/i, '');
            } catch (e) {
                console.warn('Failed to infer theme URL from stylesheet', e);
            }
            return '';
        })();

        try {
            const $loading = $(
                '<div id="loading-screen" aria-hidden="true"><div class="loading-content"><div class="loading-logo"><img src="' + themeUrl + '/assets/images/logo.svg" alt="Logo" class="loading-logo-img"></div><div class="loading-text">ENGINE DYNAMO</div><div class="loading-bar"><div class="loading-progress"></div></div></div></div>'
            );
            $('body').prepend($loading);
            console.debug('Loading screen injected. themeUrl=', themeUrl);
        } catch (err) {
            console.error('Failed to inject loading screen markup', err);
        }
    }

    // Custom error handler for all AJAX requests
    $(document).ajaxError(function(event, jqXHR, settings, error) {
        console.error('AJAX Error:', error);
        if (window.location.hostname !== 'localhost') {
            $.post(engine_dynamo_ajax.ajax_url, {
                action: 'engine_dynamo_log_error',
                nonce: engine_dynamo_ajax.nonce,
                error: `AJAX Error: ${error}`,
                url: settings.url,
                data: JSON.stringify(settings.data)
            });
        }
    });

    // Initialize everything when DOM is ready with error handling
    $(document).ready(function() {
        // Error handling wrapper with retry mechanism
        function safeInit(fn, name, maxRetries = 3) {
            let retries = 0;
            
            function tryInit() {
                try {
                    fn();
                } catch (error) {
                    console.error(`Error initializing ${name}:`, error);
                    
                    // Send error to server log if in production
                    if (window.location.hostname !== 'localhost') {
                        $.post(engine_dynamo_ajax.ajax_url, {
                            action: 'engine_dynamo_log_error',
                            nonce: engine_dynamo_ajax.nonce,
                            error: `${name} initialization error: ${error.message}`,
                            stack: error.stack,
                            retryCount: retries
                        });
                    }
                    
                    // Retry logic for certain types of errors
                    if (retries < maxRetries && 
                        (error instanceof ReferenceError || 
                         error instanceof TypeError ||
                         error.message.includes('undefined') ||
                         error.message.includes('null'))) {
                        retries++;
                        console.log(`Retrying ${name} initialization (${retries}/${maxRetries})`);
                        setTimeout(tryInit, 1000 * retries); // Exponential backoff
                    } else {
                        console.error(`Failed to initialize ${name} after ${retries} retries`);
                    }
                }
            }
            
            tryInit();
        }

        // Asset preloading with error handling
        function preloadAssets() {
            const assets = [
                `${engine_dynamo_ajax.theme_url}/assets/images/logo.svg`,
                `${engine_dynamo_ajax.theme_url}/assets/images/hero-car-1.jpg`
            ];

            const loadedAssets = new Set();
            const failedAssets = new Set();

            assets.forEach(src => {
                const img = new Image();
                
                img.onload = () => {
                    loadedAssets.add(src);
                    if (loadedAssets.size === assets.length) {
                        console.log('All assets loaded successfully');
                    }
                };
                
                img.onerror = () => {
                    failedAssets.add(src);
                    console.error(`Failed to load image: ${src}`);
                    
                    if (window.location.hostname !== 'localhost') {
                        $.post(engine_dynamo_ajax.ajax_url, {
                            action: 'engine_dynamo_log_error',
                            nonce: engine_dynamo_ajax.nonce,
                            error: `Asset load error: ${src}`,
                            type: 'asset_load_failure'
                        });
                    }
                };
                
                img.src = src;
            });
        }

        // Check for critical dependencies with detailed reporting
        function checkDependencies() {
            const dependencies = [
                { name: 'jQuery', check: () => typeof jQuery !== 'undefined' },
                { name: 'WordPress AJAX object', check: () => typeof engine_dynamo_ajax !== 'undefined' },
                { name: 'WordPress nonce', check: () => engine_dynamo_ajax && engine_dynamo_ajax.nonce },
                { name: 'Theme URL', check: () => engine_dynamo_ajax && engine_dynamo_ajax.theme_url }
            ];

            const missingDeps = dependencies.filter(dep => !dep.check());

            if (missingDeps.length > 0) {
                const missingNames = missingDeps.map(dep => dep.name).join(', ');
                console.error(`Missing dependencies: ${missingNames}`);
                
                if (window.location.hostname !== 'localhost') {
                    $.post(engine_dynamo_ajax.ajax_url, {
                        action: 'engine_dynamo_log_error',
                        error: `Missing dependencies: ${missingNames}`,
                        type: 'dependency_check_failure'
                    });
                }
                return false;
            }
            return true;
        }

        // Initialize everything with error handling and dependency checks
        if (checkDependencies()) {
            preloadAssets();
            
            const modules = [
                { fn: initAnimations, name: 'animations' },
                { fn: initNavigation, name: 'navigation' },
                { fn: initCar3D, name: 'car3D' },
                { fn: initComments, name: 'comments' },
                { fn: initContactForm, name: 'contactForm' },
                { fn: initSearch, name: 'search' },
                { fn: initNewsletter, name: 'newsletter' },
                { fn: initRating, name: 'rating' },
                { fn: initScrollEffects, name: 'scrollEffects' },
                { fn: initLoadingScreen, name: 'loadingScreen' },
                { fn: initHeaderScroll, name: 'headerScroll' },
                { fn: initReadingProgress, name: 'readingProgress' },
                { fn: initBackToTop, name: 'backToTop' },
                { fn: initNewsletterWidget, name: 'newsletterWidget' }
            ];

            modules.forEach(module => safeInit(module.fn, module.name));
        }

        // Add window error handler with improved error classification
        window.onerror = function(msg, url, lineNo, columnNo, error) {
            if (window.location.hostname !== 'localhost') {
                // Prepare error data
                const errorData = {
                    error_message: msg,
                    error_type: error ? error.name : 'unknown',
                    url: url,
                    line: lineNo,
                    column_num: columnNo,
                    stack_trace: error ? error.stack : '',
                    browser_info: navigator.userAgent
                };

                // Send to WordPress backend
                $.post(engine_dynamo_ajax.ajax_url, {
                    action: 'log_js_error',
                    error: JSON.stringify(errorData),
                    nonce: engine_dynamo_ajax.nonce
                });
            }
            return false;
        };

        // Add unhandled promise rejection handler
        window.addEventListener('unhandledrejection', function(event) {
            console.error('Unhandled promise rejection:', event.reason);
            
            if (window.location.hostname !== 'localhost') {
                const errorData = {
                    error_message: event.reason ? event.reason.message : 'Unknown Promise Rejection',
                    error_type: 'unhandled_promise_rejection',
                    url: window.location.href,
                    line: null,
                    column_num: null,
                    stack_trace: event.reason ? event.reason.stack : '',
                    browser_info: navigator.userAgent
                };

                $.post(engine_dynamo_ajax.ajax_url, {
                    action: 'log_js_error',
                    error: JSON.stringify(errorData),
                    nonce: engine_dynamo_ajax.nonce
                });
            }
        });
        
        // Add error boundary for React-like error catching
        window.addEventListener('error', function(event) {
            if (event.error && event.error.message) {
                console.error('Global error caught:', event.error);
                
                if (window.location.hostname !== 'localhost') {
                    const errorData = {
                    error_message: event.error.message,
                    error_type: event.error.name || 'event_error',
                    url: event.filename,
                    line: event.lineno,
                    column_num: event.colno,
                    stack_trace: event.error.stack,
                    browser_info: navigator.userAgent
                };

                $.post(engine_dynamo_ajax.ajax_url, {
                    action: 'log_js_error',
                    error: JSON.stringify(errorData),
                    nonce: engine_dynamo_ajax.nonce
                });
                }
            }
        });

    // Scroll-triggered animations
    function initAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        // Observe elements for animation
        document.querySelectorAll('.article-card, .post-card, .section-title, .team-member, .value-item, .contact-item, .featured-post').forEach(el => {
            observer.observe(el);
        });

        // Add CSS for animations
        const style = document.createElement('style');
        style.textContent = `
            .article-card, .post-card, .section-title, .team-member, .value-item, .contact-item, .featured-post {
                opacity: 0;
                transform: translateY(30px);
                transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
            }
            .article-card.animate-in, .post-card.animate-in, .section-title.animate-in, .team-member.animate-in, .value-item.animate-in, .contact-item.animate-in, .featured-post.animate-in {
                opacity: 1;
                transform: translateY(0);
            }
        `;
        document.head.appendChild(style);
    }

    // Navigation functionality
    function initNavigation() {
        // Mobile menu toggle
        $('.menu-toggle').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).toggleClass('active');
            $('.nav-menu').toggleClass('active');
        });

        // Dropdown menus with smooth animations for desktop
        if ($(window).width() > 768) {
            // Use class toggles for smoother CSS-driven dropdown animations
            $('.nav-item.dropdown').hover(
                function() {
                    $(this).addClass('open');
                },
                function() {
                    $(this).removeClass('open');
                }
            );
        } else {
            // Mobile dropdown handling
            // Behavior change: if the parent nav-link has a valid href (not '#' or empty) we allow navigation
            // Only links without href or with href='#' will toggle the submenu on mobile.
            $('.nav-item.dropdown .nav-link').on('click', function(e) {
                const $link = $(this);
                const href = $link.attr('href');
                const $parent = $link.parent();
                const $dropdown = $link.siblings('.dropdown-menu');

                // If there is no dropdown menu, allow normal navigation
                if (!$dropdown.length) {
                    return;
                }

                // If the link points to a real URL (not '#' or empty), allow navigation so users can visit
                // the parent category/archive page. Only intercept clicks for toggling when href is missing or '#'.
                if (href && href !== '#') {
                    return; // allow browser to navigate to href
                }

                // Handle dropdown toggle for non-navigable parent links
                e.preventDefault();

                // Close any other open dropdowns
                $('.nav-item.dropdown').not($parent).removeClass('active')
                    .find('.dropdown-menu').slideUp(300);

                // Toggle current dropdown
                $parent.toggleClass('active');
                $dropdown.stop(true, true).slideToggle(300);
            });
        }

        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.main-navigation').length) {
                $('.nav-menu').removeClass('active');
                $('.menu-toggle').removeClass('active');
                $('.nav-item.dropdown').removeClass('active');
                $('.dropdown-menu').slideUp(300);
            }
        });

        // Handle window resize
            $(window).on('resize', function() {
            if ($(window).width() > 768) {
                $('.nav-menu').removeClass('active');
                $('.menu-toggle').removeClass('active');
                // Remove inline styles and close any open dropdowns so CSS-driven animation works
                $('.dropdown-menu').removeAttr('style').removeClass('open');
                $('.nav-item.dropdown').removeClass('open');
            }
        });
    }

    // 3D Car effects
    function initCar3D() {
        const car3d = $('.car-3d');
        
        if (car3d.length) {
            car3d.on('mouseenter', function() {
                $(this).css('transform', 'perspective(1000px) rotateY(-8deg) rotateX(3deg) scale(1.02)');
            }).on('mouseleave', function() {
                $(this).css('transform', 'perspective(1000px) rotateY(-10deg) rotateX(5deg) scale(1)');
            });
        }
    }

    // AJAX Comments
    function initComments() {
        $('#commentform').on('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                action: 'engine_dynamo_comment',
                nonce: engine_dynamo_ajax.nonce,
                post_id: $('input[name="comment_post_ID"]').val(),
                author: $('input[name="author"]').val(),
                email: $('input[name="email"]').val(),
                comment: $('textarea[name="comment"]').val(),
                parent_id: $('input[name="comment_parent"]').val()
            };

            $.ajax({
                url: engine_dynamo_ajax.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    try {
                        if (response && response.success) {
                            alert('Comment submitted successfully!');
                            location.reload();
                        } else {
                            var msg = (response && response.data && response.data.message) ? response.data.message : 'Failed to submit comment.';
                            alert(msg);
                        }
                    } catch (err) {
                        console.error('Unexpected comment response shape', err, response);
                        alert('Failed to submit comment.');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var serverMsg = (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message) ? jqXHR.responseJSON.data.message : null;
                    alert(serverMsg || 'An error occurred. Please try again.');
                }
            });
        });
    }

    // Contact form with advanced validation and feedback
    function initContactForm() {
        const $form = $('#contact-form');
        const $messageField = $('#contact_message');
        const $counter = $('#message-length');
        
        // Character counter
        $messageField.on('input', function() {
            const length = $(this).val().length;
            $counter.text(length);
            if (length >= 900) {
                $counter.css('color', '#e63946');
            } else {
                $counter.css('color', '');
            }
        });

        $form.on('submit', function(e) {
            e.preventDefault();
            
            const $submitBtn = $form.find('button[type="submit"]');
            const $btnText = $submitBtn.text();
            const $response = $form.find('.form-response');
            
            // Basic validation
            const name = $('#contact_name').val();
            const email = $('#contact_email').val();
            const subject = $('#contact_subject').val();
            const message = $('#contact_message').val();
            
            // Email validation regex
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            // Validation checks
            if (!name || !email || !subject || !message) {
                showFormError('Please fill in all fields');
                return;
            }
            
            if (!emailRegex.test(email)) {
                showFormError('Please enter a valid email address');
                return;
            }
            
            if (message.length < 10) {
                showFormError('Message must be at least 10 characters long');
                return;
            }
            
            // Show loading state
            $submitBtn.prop('disabled', true)
                     .html('<i class="fas fa-circle-notch fa-spin"></i> Sending...');
            
            // Get form data
            const formData = new FormData();
            formData.append('action', 'engine_dynamo_contact');
            formData.append('contact_nonce', $form.find('input[name="contact_nonce"]').val());
            formData.append('contact_name', name);
            formData.append('contact_email', email);
            formData.append('contact_subject', subject);
            formData.append('contact_message', message);

            // AJAX submission
            $.ajax({
                url: engine_dynamo_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    try {
                        if (response && response.success) {
                            showFormSuccess('Message sent successfully! We\'ll get back to you soon.');
                            $form[0].reset();
                        } else {
                            var msg = (response && response.data && response.data.message) ? response.data.message : 'Failed to send message. Please try again.';
                            showFormError(msg);
                        }
                    } catch (err) {
                        console.error('Unexpected contact response', err, response);
                        showFormError('Failed to send message. Please try again.');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var serverMsg = (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message) ? jqXHR.responseJSON.data.message : null;
                    showFormError(serverMsg || 'An error occurred. Please try again later.');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text($btnText);
                }
            });
            
            // Helper functions
            function showFormError(message) {
                $response.removeClass('success').addClass('error')
                    .html(`<i class="fas fa-exclamation-circle"></i> ${message}`)
                    .fadeIn();
                
                setTimeout(() => {
                    $response.fadeOut();
                }, 5000);
            }
            
            function showFormSuccess(message) {
                $response.removeClass('error').addClass('success')
                    .html(`<i class="fas fa-check-circle"></i> ${message}`)
                    .fadeIn();
                
                setTimeout(() => {
                    $response.fadeOut();
                }, 5000);
            }
        });
    }

    // Live search
    function initSearch() {
        let searchTimeout;
        
        $('.search-field').on('input', function() {
            const searchTerm = $(this).val();
            
            clearTimeout(searchTimeout);
            
            if (searchTerm.length > 2) {
                searchTimeout = setTimeout(() => {
                    $.ajax({
                        url: engine_dynamo_ajax.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'engine_dynamo_search',
                            nonce: engine_dynamo_ajax.nonce,
                            search_term: searchTerm
                        },
                        success: function(response) {
                            try {
                                if (response && response.success) {
                                    displaySearchResults(response.data);
                                } else {
                                    console.warn('Search returned no results or error', response);
                                }
                            } catch (err) {
                                console.error('Unexpected search response', err, response);
                            }
                        }
                    });
                }, 300);
            }
        });
    }

    // Display search results
    function displaySearchResults(results) {
        // Implementation for displaying search results
        console.log('Search results:', results);
    }

    // Newsletter subscription with advanced validation and user feedback
    function initNewsletter() {
        let submitCount = 0; // Track submission attempts
        $('.newsletter-form').each(function() {
            const $form = $(this);
            const $submitBtn = $form.find('.subscribe-btn');
            const $input = $form.find('.email-input');
            const $response = $form.find('.newsletter-response');
            let subscribeTimeout;
            
            // Email validation
            $input.on('input', function() {
                const email = $(this).val();
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                
                if (email && !emailRegex.test(email)) {
                    $(this).addClass('invalid');
                } else {
                    $(this).removeClass('invalid');
                }
            });
            
            $form.on('submit', function(e) {
                e.preventDefault();
                clearTimeout(subscribeTimeout);
                
                const email = $input.val();
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                
                // Validation
                if (!email) {
                    showResponse('error', 'Please enter your email address');
                    return;
                }
                
                if (!emailRegex.test(email)) {
                    showResponse('error', 'Please enter a valid email address');
                    return;
                }
                
                // Show loading state
                $submitBtn.prop('disabled', true)
                         .html('<i class="fas fa-circle-notch fa-spin"></i>');
                
                // Clear previous messages
                $response.removeClass('success error').empty();
                
                // Prevent excessive submissions
                if (submitCount >= 3) {
                    showResponse('error', 'Too many attempts. Please try again later.');
                    return;
                }
                submitCount++;

                // Submit form
                $.ajax({
                    url: engine_dynamo_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'engine_dynamo_newsletter',
                        nonce: engine_dynamo_ajax.nonce,
                        email: email
                    },
                    success: function(response) {
                        try {
                            if (response && response.success) {
                                showResponse('success', 
                                    'Almost there! Please check your email to confirm your subscription. ' +
                                    '<i class="fas fa-envelope"></i>'
                                );
                                $form[0].reset();

                                // Show confetti animation
                                showConfetti();
                            } else {
                                var msg = (response && response.data && response.data.message) ? response.data.message : 'Subscription failed. Please try again.';
                                showResponse('error', msg);
                            }
                        } catch (err) {
                            console.error('Unexpected newsletter response', err, response);
                            showResponse('error', 'Subscription failed. Please try again.');
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        var serverMsg = (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message) ? jqXHR.responseJSON.data.message : null;
                        showResponse('error', serverMsg || 'An error occurred. Please try again later.');
                    },
                    complete: function() {
                        // Reset button
                        $submitBtn.prop('disabled', false).text('Subscribe');
                    }
                });
            });
            
            // Helper function to show response messages
            function showResponse(type, message) {
                // Clear any existing timeouts
                clearTimeout(subscribeTimeout);
                
                $response.removeClass('success error')
                         .addClass(type)
                         .html(message)
                         .fadeIn();
                
                // Auto-hide message after 5 seconds
                subscribeTimeout = setTimeout(() => {
                    $response.fadeOut();
                }, 5000);
            }
            
            // Confetti animation for successful subscription
            function showConfetti() {
                const colors = ['#2B6EF2', '#38BDF8', '#E63946', '#ffffff'];
                const confettiCount = 100;
                
                for (let i = 0; i < confettiCount; i++) {
                    createConfetti(colors[Math.floor(Math.random() * colors.length)]);
                }
            }
            
            function createConfetti(color) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.backgroundColor = color;
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
                confetti.style.opacity = Math.random();
                confetti.style.transform = 'rotate(' + (Math.random() * 360) + 'deg)';
                
                document.body.appendChild(confetti);
                
                setTimeout(() => {
                    confetti.remove();
                }, 5000);
            }
        });
        
        // Add confetti styles
        if (!document.getElementById('confetti-style')) {
            const style = document.createElement('style');
            style.id = 'confetti-style';
            style.textContent = `
                .confetti {
                    position: fixed;
                    top: -10px;
                    z-index: 9999;
                    width: 10px;
                    height: 10px;
                    pointer-events: none;
                    animation: confetti-fall linear forwards;
                }
                @keyframes confetti-fall {
                    to {
                        transform: translateY(100vh) rotate(360deg);
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }
    });

    // Rating system
    function initRating() {
        $('.star').on('click', function() {
            const rating = $(this).data('rating');
            const postId = $(this).closest('.stars').data('post-id');
            
            $.ajax({
                url: engine_dynamo_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'engine_dynamo_rating',
                    nonce: engine_dynamo_ajax.nonce,
                    post_id: postId,
                    rating: rating
                },
                success: function(response) {
                    if (response.success) {
                        $('.rating-info').html(
                            '<span class="average-rating">' + response.data.average + '</span> ' +
                            '(<span class="rating-count">' + response.data.count + '</span> ratings)'
                        );
                    }
                }
            });
        });
    }

    // Scroll effects
    function initScrollEffects() {
        let lastScrollTop = 0;
        let ticking = false;

        // Create scroll-progress once for performance
        if (!$('.scroll-progress').length) {
            $('body').append('<div class="scroll-progress"></div>');
            $('<style>.scroll-progress{position:fixed;top:0;left:0;width:0;height:3px;background:#2B6EF2;z-index:9999;transition:width 0.25s ease;}</style>').appendTo('head');
        }

        // Throttled scroll handler using requestAnimationFrame
        $(window).on('scroll', function() {
            const scrollTop = $(this).scrollTop();

            if (!ticking) {
                window.requestAnimationFrame(function() {
                    // Header background opacity
                    if (scrollTop > 100) {
                        $('.site-header').css('background', 'rgba(10, 15, 28, 0.98)');
                    } else {
                        $('.site-header').css('background', 'rgba(10, 15, 28, 0.95)');
                    }

                    // Parallax for hero section (only if element exists)
                    if ($('.hero-car').length && scrollTop < $(window).height()) {
                        $('.hero-car').css('transform', 'translateY(' + (scrollTop * 0.5) + 'px)');
                    }

                    // Scroll progress indicator
                    const winHeight = $(window).height();
                    const docHeight = $(document).height();
                    const scrollPercent = (scrollTop / Math.max(1, (docHeight - winHeight))) * 100;
                    $('.scroll-progress').css('width', scrollPercent + '%');

                    lastScrollTop = scrollTop;
                    ticking = false;
                });
                ticking = true;
            }
        });
    }

    // Loading screen
    function initLoadingScreen() {
        // Set up the loading screen with progress tracking
        let assetsLoaded = 0;
        let totalAssets = 0;
        let loadingComplete = false;
        
        // Update progress bar
        function updateProgress(progress) {
            $('.loading-progress').css('width', progress + '%');
        }

        // Create an array of critical assets to preload
        const criticalAssets = [
            // Logo
            `${engine_dynamo_ajax.theme_url}/assets/images/logo.svg`,
            // Critical CSS files
            `${engine_dynamo_ajax.theme_url}/assets/css/hero-main.css`,
            // Critical images
            `${engine_dynamo_ajax.theme_url}/assets/images/hero-car-1.jpg`
        ];
        
        totalAssets = criticalAssets.length;
        
        // Preload each critical asset
        criticalAssets.forEach(asset => {
            if (asset.endsWith('.css')) {
                $.ajax({
                    url: asset,
                    success: () => {
                        assetsLoaded++;
                        updateProgress((assetsLoaded / totalAssets) * 100);
                    }
                });
            } else {
                const img = new Image();
                img.onload = img.onerror = () => {
                    assetsLoaded++;
                    updateProgress((assetsLoaded / totalAssets) * 100);
                };
                img.src = asset;
            }
        });
        
        // Primary loading check on window load
        $(window).on('load', function() {
            loadingComplete = true;
            $('#loading-screen').fadeOut(800, function() {
                $(this).remove();
            });
        });
        
        // Multiple fallback timers with progress checks
        const fallbackTimer1 = setTimeout(() => {
            if (!loadingComplete && assetsLoaded >= totalAssets) {
                loadingComplete = true;
                $('#loading-screen').fadeOut(800, function() {
                    $(this).remove();
                });
            }
        }, 3000);
        
        const fallbackTimer2 = setTimeout(() => {
            if (!loadingComplete) {
                loadingComplete = true;
                $('#loading-screen').fadeOut(800, function() {
                    $(this).remove();
                });
                console.warn('Loading screen removed by final fallback timer');
            }
        }, 5000);
        
        // Clean up timers if page load completes normally
        $(window).on('load', function() {
            clearTimeout(fallbackTimer1);
            clearTimeout(fallbackTimer2);
        });
    }

    // Smooth scrolling for anchor links
    $('a[href*="#"]').on('click', function(e) {
        const target = $(this.getAttribute('href'));
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top - 80
            }, 800);
        }
    });

    // Smooth hover effects for cards (removed tilt/skew effects)
    $('.article-card, .post-card').on('mouseenter', function() {
        $(this).css('transform', 'translateY(-5px)');
    }).on('mouseleave', function() {
        $(this).css('transform', 'translateY(0)');
    });

    // Text reveal animation
    function revealText() {
        $('.hero-title .engine, .hero-title .dynamo').each(function() {
            const text = $(this).text();
            $(this).html(text.split('').map(char => `<span>${char}</span>`).join(''));

            $(this).find('span').each(function(index) {
                $(this).css({
                    'opacity': '0',
                    'transform': 'translateY(20px)',
                    'transition': `all 0.3s ease ${index * 0.05}s`
                });
            });
        });

        setTimeout(() => {
            $('.hero-title .engine span, .hero-title .dynamo span').css({
                'opacity': '1',
                'transform': 'translateY(0)'
            });
        }, 200);
    }

    // Initialize text reveal
    setTimeout(revealText, 500);

    // Header scroll effects
    function initHeaderScroll() {
        $(window).on('scroll', function() {
            const scrollTop = $(this).scrollTop();
            
            if (scrollTop > 50) {
                $('.site-header').addClass('scrolled');
            } else {
                $('.site-header').removeClass('scrolled');
            }
        });
    }

    // Reading progress bar
    function initReadingProgress() {
        if ($('.single-post').length) {
            $('body').prepend('<div class="reading-progress"></div>');
            
            $(window).on('scroll', function() {
                const scrollTop = $(this).scrollTop();
                const docHeight = $(document).height() - $(window).height();
                const scrollPercent = (scrollTop / docHeight) * 100;
                
                $('.reading-progress').css('width', scrollPercent + '%');
            });
        }
    }

    // Back to top button
    function initBackToTop() {
        $('body').append('<button class="back-to-top" title="Back to Top">↑</button>');
        
        $(window).on('scroll', function() {
            if ($(this).scrollTop() > 300) {
                $('.back-to-top').addClass('visible');
            } else {
                $('.back-to-top').removeClass('visible');
            }
        });
        
        $('.back-to-top').on('click', function() {
            $('html, body').animate({scrollTop: 0}, 800);
        });
    }

    // Newsletter widget
    function initNewsletterWidget() {
        // Add newsletter widget to sidebar if it exists
        if ($('.sidebar').length && !$('.newsletter-widget').length) {
            $('.sidebar').prepend(`
                <div class="widget newsletter-widget">
                    <h3 class="widget-title">Stay Updated</h3>
                    <p class="widget-description">Get the latest automotive news and tips delivered to your inbox.</p>
                    <form class="newsletter-form">
                        <div class="input-group">
                            <input type="email" class="email-input" placeholder="Enter your email" required>
                            <button type="submit" class="subscribe-btn">
                                <span class="btn-text">Subscribe</span>
                                <span class="btn-loading" style="display: none;">Subscribing...</span>
                            </button>
                        </div>
                        <div class="newsletter-message"></div>
                    </form>
                </div>
            `);
        }
    }

})(jQuery);
