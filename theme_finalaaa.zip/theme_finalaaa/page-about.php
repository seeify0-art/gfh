<?php
/**
 * The template for displaying the About page
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <!-- About Page Header -->
        <header class="page-header">
            <h1 class="page-title">About Us</h1>
            <p class="page-description">Your trusted source for automotive expertise and insights</p>
        </header>

        <div class="about-content">
            
            <!-- Mission Section -->
            <section class="mission-section">
                <h2>Our Mission</h2>
                <p>At Engine Dynamo, we're passionate about everything automotive. Our mission is to provide you with the most comprehensive, accurate, and up-to-date information about cars, maintenance, and the automotive industry.</p>
                <p>Whether you're a car enthusiast, a DIY mechanic, or someone looking to make an informed purchase, we're here to guide you through the complex world of automobiles.</p>
            </section>

            <!-- Team Section -->
            <section class="team-section">
                <h2>Meet Our Team</h2>
                <div class="team-grid">
                    <div class="team-member">
                        <div class="team-avatar">
                            <span class="avatar-placeholder">👨‍💻</span>
                        </div>
                        <h3>Rohan Ahmed</h3>
                        <p class="team-role">Automotive Journalist</p>
                        <p class="team-bio">Rohan brings his passion for automotive journalism and storytelling to deliver engaging content that connects with car enthusiasts worldwide.</p>
                    </div>
                </div>
            </section>

            <!-- Values Section -->
            <section class="values-section">
                <h2>Our Values</h2>
                <div class="values-grid">
                    <div class="value-item">
                        <div class="value-icon">🎯</div>
                        <h3>Accuracy</h3>
                        <p>We ensure all our content is fact-checked and verified by automotive experts.</p>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">🤝</div>
                        <h3>Trust</h3>
                        <p>Building trust through transparent, honest, and reliable automotive information.</p>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">💡</div>
                        <h3>Innovation</h3>
                        <p>Staying ahead with the latest automotive trends and technologies.</p>
                    </div>
                    
                    <div class="value-item">
                        <div class="value-icon">🌍</div>
                        <h3>Community</h3>
                        <p>Fostering a community of car enthusiasts and automotive professionals.</p>
                    </div>
                </div>
            </section>

            <!-- Contact CTA -->
            <section class="contact-cta">
                <h2>Get in Touch</h2>
                <p>Have questions about cars, maintenance, or automotive topics? We'd love to hear from you!</p>
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary">Contact Us</a>
            </section>
            
        </div>
        
    </div>
</main>

<?php
get_footer();