<?php
/**
 * The template for displaying all pages
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <div class="page-wrapper">
            
            <?php while (have_posts()) : the_post(); ?>
                <article id="page-<?php the_ID(); ?>" <?php post_class('page-content'); ?>>
                    
                    <!-- Page Header -->
                    <header class="page-header">
                        <h1 class="page-title"><?php the_title(); ?></h1>
                    </header>

                    <!-- Page Content -->
                    <div class="page-content">
                        <?php
                        the_content();
                        
                        wp_link_pages(array(
                            'before' => '<div class="page-links">' . esc_html__('Pages:', 'engine-dynamo'),
                            'after'  => '</div>',
                        ));
                        ?>
                    </div>

                </article>
            <?php endwhile; ?>

        </div>
    </div>
</main>

<?php
get_footer();
