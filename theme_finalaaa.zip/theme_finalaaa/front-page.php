<?php
/**
 * Front Page Template
 * Uses hero + featured articles layout matching the reference design
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <!-- Hero Section -->
    <?php get_template_part('template-parts/hero-slider'); ?>

    <!-- Featured Articles Section -->
    <section class="featured-section">
        <div class="container">
            <h2 class="section-title">Featured Articles</h2>
            
            <div class="articles-grid">
                <?php
                $featured_posts = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                    'post_status' => 'publish'
                ));
                
                if ($featured_posts->have_posts()) :
                    while ($featured_posts->have_posts()) : $featured_posts->the_post();
                ?>
                    <article class="article-card">
                        <div class="article-thumbnail">
                            <a href="<?php the_permalink(); ?>">
                                <?php if (has_post_thumbnail()) {
                                    the_post_thumbnail('article-thumbnail');
                                } else { ?>
                                    <div class="placeholder-image">
                                        <span class="placeholder-icon">🚗</span>
                                        <span class="placeholder-text">Automotive</span>
                                    </div>
                                <?php } ?>
                            </a>
                        </div>
                        
                        <h3 class="article-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        
                        <div class="article-meta">
                            <span class="article-date"><?php echo get_the_date(); ?></span>
                            <span class="article-category"><?php the_category(', '); ?></span>
                        </div>
                        
                        <div class="article-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        
                        <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                    </article>
                <?php
                    endwhile;
                    wp_reset_postdata();
                endif; ?>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();
