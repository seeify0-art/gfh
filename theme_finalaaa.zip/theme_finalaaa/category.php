<?php
/**
 * The template for displaying category pages
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">

        <!-- Category Header -->
        <header class="category-header">
            <div class="category-title-wrapper">
                <?php
                // Get current category
                $current_category = get_queried_object();
                
                // Get category name
                $category_name = single_cat_title('', false);
                ?>
                <h1 class="category-title"><?php echo esc_html($category_name); ?></h1>

                <?php
                // Display category description if available
                $category_description = category_description();
                if (!empty($category_description)) :
                ?>
                    <div class="category-description">
                        <?php echo $category_description; ?>
                    </div>
                <?php endif; ?>
            </div>
        </header>
        </header>

        <!-- Category Layout -->
        <div class="blog-layout">

            <!-- Main Content -->
            <div class="blog-content">
                <!-- Posts Grid -->
                <div class="posts-grid">
                <?php
                // Get current category and ALL its descendants recursively
                $current_category = get_queried_object();
                $category_ids = array($current_category->term_id);

                // Get all subcategory IDs recursively
                $descendants = engine_dynamo_get_all_category_descendants($current_category->term_id);
                $category_ids = array_merge($category_ids, $descendants);

                // Custom query to include posts from current category and ALL subcategories recursively
                // Use the site's posts_per_page and respect pagination
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => get_option('posts_per_page'),
                    'paged' => $paged,
                    'post_status' => 'publish',
                    'category__in' => $category_ids,
                    'orderby' => 'date',
                    'order' => 'DESC'
                );

                $category_posts = new WP_Query($args);

                if ($category_posts->have_posts()) :
                    while ($category_posts->have_posts()) : $category_posts->the_post();
                ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>

                            <?php if (has_post_thumbnail()) : ?>
                                <div class="post-thumbnail">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail('article-thumbnail'); ?>
                                    </a>
                                </div>
                            <?php else : ?>
                                <div class="post-thumbnail">
                                    <a href="<?php the_permalink(); ?>">
                                        <div class="placeholder-image">
                                            <span class="placeholder-icon">🚗</span>
                                            <span class="placeholder-text">Automotive</span>
                                        </div>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <div class="post-content">
                                <div class="post-meta">
                                    <span class="post-date"><?php echo get_the_date(); ?></span>
                                    <span class="post-category"><?php the_category(', '); ?></span>
                                    <span class="post-author">By <?php the_author(); ?></span>
                                    <span class="reading-time"><?php echo engine_dynamo_display_reading_time(); ?></span>
                                </div>

                                <h2 class="post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>

                                <div class="post-excerpt">
                                    <?php echo wp_trim_words(get_the_content(), 20, '...'); ?>
                                </div>

                                <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                            </div>
                        </article>
                    <?php endwhile; ?>
                    <?php wp_reset_postdata(); ?>

                    <!-- Pagination -->
                    <?php
                    // Paginate the custom query
                    the_posts_pagination(array(
                        'prev_text' => esc_html__('Previous', 'engine-dynamo'),
                        'next_text' => esc_html__('Next', 'engine-dynamo'),
                        'mid_size' => 2,
                        'total' => $category_posts->max_num_pages,
                    ));
                    ?>

                <?php else : ?>
                    
                    <!-- No Posts -->
                    <div class="no-posts">
                        <h2><?php esc_html_e('No posts found', 'engine-dynamo'); ?></h2>
                        <p><?php esc_html_e('Sorry, no posts were found in this category.', 'engine-dynamo'); ?></p>
                        <a href="<?php echo home_url(); ?>" class="btn btn-primary">Go Home</a>
                    </div>

                <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="sidebar">
                <?php get_sidebar(); ?>
            </div>

        </div>
    </div>
</main>

<?php
get_footer();
