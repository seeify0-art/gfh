<?php
/**
 * Template for displaying the contact page
 *
 * @package EngineDynamo
 */

// Handle form submission before header output
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_nonce']) && wp_verify_nonce($_POST['contact_nonce'], 'engine_dynamo_contact_form')) {

    // Sanitize and validate fields
    $name    = sanitize_text_field($_POST['contact_name'] ?? '');
    $email   = sanitize_email($_POST['contact_email'] ?? '');
    $subject = sanitize_text_field($_POST['contact_subject'] ?? '');
    $message = sanitize_textarea_field($_POST['contact_message'] ?? '');

    // Basic validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        wp_safe_redirect(add_query_arg('contact', 'validation_error', get_permalink()));
        exit;
    }

    if (!is_email($email)) {
        wp_safe_redirect(add_query_arg('contact', 'invalid_email', get_permalink()));
        exit;
    }

    // Simple spam prevention
    if (preg_match('/https?:\/\//i', $message)) {
        wp_safe_redirect(add_query_arg('contact', 'spam_detected', get_permalink()));
        exit;
    }

    // Limit form submissions (basic rate limiting by IP)
    $ip = $_SERVER['REMOTE_ADDR'];
    $last_submission = get_transient('contact_form_' . md5($ip));
    if ($last_submission) {
        wp_safe_redirect(add_query_arg('contact', 'rate_limit', get_permalink()));
        exit;
    } else {
        set_transient('contact_form_' . md5($ip), '1', HOUR_IN_SECONDS);
    }

    // Email details
    $to = 'info@enginedynamo.com'; // ✅ The destination email address
    $headers = [
        'From: ' . $name . ' <' . $email . '>',
        'Reply-To: ' . $email,
        'Content-Type: text/html; charset=UTF-8'
    ];

    $body = "
        <h2>New Contact Form Message</h2>
        <p><strong>Name:</strong> {$name}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Subject:</strong> {$subject}</p>
        <p><strong>Message:</strong><br>" . nl2br($message) . "</p>
        <hr>
        <p>Sent from: " . home_url() . "</p>
    ";

    // Send the email
    if (wp_mail($to, 'Contact Form: ' . $subject, $body, $headers)) {
        wp_safe_redirect(add_query_arg('contact', 'success', get_permalink()));
        exit;
    } else {
        wp_safe_redirect(add_query_arg('contact', 'error', get_permalink()));
        exit;
    }
}

get_header();
?>

<main id="primary" class="site-main">
    <div class="container">

        <!-- Contact Page Header -->
        <header class="page-header">
            <h1 class="page-title">Contact Us</h1>
            <p class="page-description">Get in touch with our automotive experts. We'd love to hear from you!</p>
        </header>

        <div class="contact-content">
            <!-- Contact Form Messages -->
            <?php if (isset($_GET['contact'])) : ?>
                <div class="contact-messages">
                    <?php
                    $message_type = $_GET['contact'];
                    switch ($message_type) {
                        case 'success':
                            echo '<div class="alert alert-success">✅ Thank you! Your message has been sent successfully. We\'ll get back to you soon.</div>';
                            break;
                        case 'error':
                            echo '<div class="alert alert-error">❌ Sorry, there was an error sending your message. Please try again.</div>';
                            break;
                        case 'validation_error':
                            echo '<div class="alert alert-error">⚠️ Please fill in all required fields.</div>';
                            break;
                        case 'invalid_email':
                            echo '<div class="alert alert-error">⚠️ Please enter a valid email address.</div>';
                            break;
                        case 'spam_detected':
                            echo '<div class="alert alert-error">🚫 Your message appears to be spam. Please try again with a different message.</div>';
                            break;
                        case 'rate_limit':
                            echo '<div class="alert alert-error">⏳ Too many submissions. Please wait an hour before trying again.</div>';
                            break;
                    }
                    ?>
                </div>
            <?php endif; ?>

            <div class="contact-grid">
                <!-- Contact Form -->
                <div class="contact-form-section">
                    <h2>Send us a Message</h2>
                    <form id="contact-form" class="contact-form" method="post" action="">
                        <?php wp_nonce_field('engine_dynamo_contact_form', 'contact_nonce'); ?>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="contact_name">Name *</label>
                                <input type="text" id="contact_name" name="contact_name" required 
                                    minlength="2" maxlength="50" pattern="[A-Za-z0-9\s]+" 
                                    title="Please enter a valid name (letters, numbers, and spaces only)">
                            </div>
                            <div class="form-group">
                                <label for="contact_email">Email *</label>
                                <input type="email" id="contact_email" name="contact_email" required 
                                    pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" 
                                    title="Please enter a valid email address">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="contact_subject">Subject *</label>
                            <input type="text" id="contact_subject" name="contact_subject" required 
                                minlength="5" maxlength="100">
                        </div>

                        <div class="form-group">
                            <label for="contact_message">Message *</label>
                            <textarea id="contact_message" name="contact_message" rows="6" required 
                                minlength="20" maxlength="1000"></textarea>
                            <div class="message-counter"><span id="message-length">0</span>/1000</div>
                        </div>

                        <!-- Honeypot field - hidden from users -->
                        <div class="website-field" aria-hidden="true">
                            <input type="text" name="website" tabindex="-1" autocomplete="off">
                        </div>

                        <div class="form-response"></div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <span class="btn-text">Send Message</span>
                                <span class="btn-loading">Sending...</span>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Contact Information -->
                <div class="contact-info-section">
                    <h2>Get in Touch</h2>
                    <div class="contact-info">
                        <div class="contact-item">
                            <div class="contact-icon">📧</div>
                            <div class="contact-details">
                                <h3>Email</h3>
                                <p>info@enginedynamo.com</p>
                            </div>
                        </div>
                    </div>

                    <!-- Social Media -->
                    <div class="social-media">
                        <h3>Follow Us</h3>
                        <div class="social-links">
                            <a href="https://www.facebook.com/profile.php?id=61580498813187" class="social-link facebook">Facebook</a>
                            <a href="https://www.instagram.com/engine_dynamo/" class="social-link instagram">Instagram</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</main>

<?php get_footer(); ?>
