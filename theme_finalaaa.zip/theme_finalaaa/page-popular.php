<?php
/**
 * Template Name: Popular Posts Page
 * The template for displaying popular posts by view count
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        <div class="content-wrapper">
            
            <!-- Popular Posts Header -->
            <header class="page-header">
                <h1 class="page-title">Popular Posts</h1>
                <p class="page-description">Discover our most read and highly rated automotive articles.</p>
            </header>

            <div class="blog-layout">
                <!-- Main Content -->
                <div class="main-content">
                    
                    <!-- Popular Posts Grid -->
                    <div class="posts-grid">
                        <?php
                        $popular_posts = new WP_Query(array(
                            'post_type' => 'post',
                            'posts_per_page' => 12,
                            'meta_key' => '_post_views',
                            'orderby' => 'meta_value_num',
                            'order' => 'DESC',
                            'post_status' => 'publish'
                        ));
                        
                        if ($popular_posts->have_posts()) : ?>
                            <?php while ($popular_posts->have_posts()) : $popular_posts->the_post(); ?>
                                <article id="post-<?php the_ID(); ?>" <?php post_class('post-card'); ?>>
                                    
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="post-thumbnail">
                                            <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('article-thumbnail'); ?>
                                            </a>
                                        </div>
                                    <?php else : ?>
                                        <div class="post-thumbnail">
                                            <a href="<?php the_permalink(); ?>">
                                                <div class="placeholder-image">
                                                    <span class="placeholder-icon">🚗</span>
                                                    <span class="placeholder-text">Automotive</span>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="post-content">
                                        <div class="post-meta">
                                            <span class="post-date"><?php echo get_the_date(); ?></span>
                                            <span class="post-category"><?php the_category(', '); ?></span>
                                            <span class="post-author">By <?php the_author(); ?></span>
                                        </div>
                                        
                                        <h2 class="post-title">
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </h2>
                                        
                                        <div class="post-excerpt">
                                            <?php the_excerpt(); ?>
                                        </div>
                                        
                                        <div class="post-stats">
                                            <?php
                                            $views = get_post_meta(get_the_ID(), '_post_views', true);
                                            $views = $views ? $views : 0;
                                            $average_rating = get_post_meta(get_the_ID(), '_average_rating', true);
                                            $rating_count = count(get_post_meta(get_the_ID(), '_post_ratings', true));
                                            ?>
                                            <div class="stat-item">
                                                <span class="stat-icon">👁️</span>
                                                <span class="stat-text"><?php echo $views; ?> views</span>
                                            </div>
                                            <?php if ($average_rating) : ?>
                                                <div class="stat-item">
                                                    <span class="stat-icon">⭐</span>
                                                    <span class="stat-text"><?php echo round($average_rating, 1); ?> (<?php echo $rating_count; ?> ratings)</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                                    </div>
                                </article>
                            <?php endwhile; ?>

                            <!-- Pagination -->
                            <?php
                            the_posts_pagination(array(
                                'prev_text' => esc_html__('Previous', 'engine-dynamo'),
                                'next_text' => esc_html__('Next', 'engine-dynamo'),
                                'mid_size' => 2,
                            ));
                            ?>

                        <?php else : ?>
                            
                            <!-- No Posts -->
                            <div class="no-posts">
                                <h2><?php esc_html_e('No popular posts found', 'engine-dynamo'); ?></h2>
                                <p><?php esc_html_e('Sorry, no popular posts were found.', 'engine-dynamo'); ?></p>
                                <a href="<?php echo home_url(); ?>" class="btn btn-primary">Go Home</a>
                            </div>

                        <?php endif; ?>
                    </div>

                </div>

                <!-- Sidebar -->
                <aside class="sidebar">
                    <div class="widget">
                        <h3 class="widget-title">About Popular Posts</h3>
                        <div class="widget-description">
                            <p>These are our most read and highly rated articles, determined by view count and user ratings.</p>
                        </div>
                    </div>

                    <div class="widget">
                        <h3 class="widget-title">Top Categories</h3>
                        <ul class="categories-list">
                            <?php
                            wp_list_categories(array(
                                'title_li' => '',
                                'show_count' => true,
                                'orderby' => 'count',
                                'order' => 'DESC',
                                'number' => 5
                            ));
                            ?>
                        </ul>
                    </div>

                    <div class="widget">
                        <h3 class="widget-title">Newsletter</h3>
                        <div class="widget-description">
                            <p>Subscribe to get notified about our most popular content.</p>
                        </div>
                        <form class="newsletter-form">
                            <div class="input-group">
                                <input type="email" class="email-input" placeholder="Your email address" required>
                                <button type="submit" class="subscribe-btn">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </aside>
            </div>

        </div>
    </div>
</main>

<?php
get_footer();
