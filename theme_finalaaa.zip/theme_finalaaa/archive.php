<?php
/**
 * The template for displaying archive pages
 *
 * @package EngineDynamo
 */

get_header(); ?>

<main id="primary" class="site-main">
    <div class="container">
        
        <!-- Archive Header -->
        <header class="page-header">
            <?php
            the_archive_title('<h1 class="page-title">', '</h1>');
            the_archive_description('<div class="page-description">', '</div>');
            ?>
        </header>

        <!-- Blog Layout -->
        <div class="blog-layout">
            
            <!-- Main Content -->
            <div class="blog-content">
                <div class="posts-grid">
                    <?php
                    if (have_posts()) :
                        while (have_posts()) : the_post();
                    ?>
                        <article class="post-card">
                            <div class="post-thumbnail">
                                    <a href="<?php the_permalink(); ?>">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <?php the_post_thumbnail('article-thumbnail'); ?>
                                    <?php else : ?>
                                        <div class="placeholder-image">
                                            <span class="placeholder-icon">🚗</span>
                                            <span class="placeholder-text">Automotive</span>
                                        </div>
                                    <?php endif; ?>
                                </a>
                            </div>
                            
                            <div class="post-content">
                                <div class="post-meta">
                                    <span class="post-date"><?php echo get_the_date(); ?></span>
                                    <span class="post-category"><?php the_category(', '); ?></span>
                                </div>
                                
                                <h2 class="post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                
                                <div class="post-excerpt">
                                    <?php the_excerpt(); ?>
                                </div>
                                
                                <a href="<?php the_permalink(); ?>" class="read-more-btn">Read More</a>
                            </div>
                        </article>
                    <?php
                        endwhile;
                        
                        // Pagination
                        the_posts_pagination(array(
                            'prev_text' => '← Previous',
                            'next_text' => 'Next →',
                        ));
                        
                    else :
                    ?>
                        <div class="no-posts">
                            <div class="no-posts-icon">📝</div>
                            <h2>No Posts Found</h2>
                            <p>No posts found in this category. Check back soon for new content!</p>
                            <a href="<?php echo esc_url(home_url('/blog')); ?>" class="btn btn-primary">View All Posts</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="sidebar">
                <?php get_sidebar(); ?>
            </div>
            
        </div>
        
    </div>
</main>

<?php
get_footer();