<!-- All Posts Section -->
<section class="all-posts-section" style="margin: 60px 0;">
    <h2 class="section-title" style="font-size: 2rem; text-align: center; margin-bottom: 40px;">All Articles</h2>

    <div class="posts-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 2rem; max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        <?php
        // Use pagination instead of loading ALL posts at once
        $paged = (get_query_var('page')) ? get_query_var('page') : 1;

        $all_posts = new WP_Query(array(
            'post_type'      => 'post',
            'posts_per_page' => 9, // 9 posts per page for balanced grid
            'paged'          => $paged,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC'
        ));

        if ($all_posts->have_posts()) :
            while ($all_posts->have_posts()) : $all_posts->the_post();
        ?>
            <article class="post-card" style="border: 1px solid #ddd; border-radius: 8px; overflow: hidden; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,0.1); transition: transform 0.2s;">
                <div class="post-thumbnail" style="overflow: hidden;">
                    <a href="<?php the_permalink(); ?>" style="display: block; aspect-ratio: 16/10; overflow: hidden;">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('article-thumbnail', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                        <?php else : ?>
                            <div style="display:flex;align-items:center;justify-content:center;height:100%;background:#f4f4f4;font-size:2rem;">🚗</div>
                        <?php endif; ?>
                    </a>
                </div>

                <div class="post-content" style="padding: 20px;">
                    <div class="post-meta" style="font-size: 0.9rem; color: #777; margin-bottom: 8px;">
                        <span class="post-date"><?php echo get_the_date(); ?></span> |
                        <span class="post-category"><?php the_category(', '); ?></span> |
                        <span class="reading-time"><?php echo engine_dynamo_display_reading_time(); ?></span>
                    </div>

                    <h3 class="post-title" style="margin: 0 0 10px 0; font-size: 1.25rem;">
                        <a href="<?php the_permalink(); ?>" style="color: #333; text-decoration: none;"><?php the_title(); ?></a>
                    </h3>

                    <div class="post-excerpt" style="color: #555; font-size: 0.95rem; margin-bottom: 15px;">
                        <?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?>
                    </div>

                    <a href="<?php the_permalink(); ?>" class="read-more-btn" style="display:inline-block;padding:8px 16px;background:#0073aa;color:#fff;border-radius:4px;text-decoration:none;font-size:0.9rem;">Read More</a>
                </div>
            </article>
        <?php
            endwhile;
            wp_reset_postdata();
        ?>
    </div>

    <!-- Pagination -->
    <div class="pagination" style="text-align:center;margin-top:40px;">
        <?php
        echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => '?page=%#%',
            'current' => $paged,
            'total' => $all_posts->max_num_pages,
            'prev_text' => '&laquo; Previous',
            'next_text' => 'Next &raquo;',
            'type' => 'list',
        ));
        ?>
    </div>

    <?php else : ?>
        <div class="no-posts" style="text-align:center; padding:40px;">
            <div style="font-size:3rem;">📝</div>
            <h2>No Posts Found</h2>
            <p>We're working on creating amazing automotive content for you. Check back soon!</p>
            <a href="<?php echo esc_url(home_url('/')); ?>" style="display:inline-block;margin-top:15px;padding:10px 20px;background:#0073aa;color:#fff;border-radius:4px;text-decoration:none;">Go Home</a>
        </div>
    <?php endif; ?>
</section>
