<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <!-- Favicon (theme logo). We try an inline SVG data-uri first (works in modern Chrome/Edge/Firefox),
         then fall back to a theme-root favicon.ico for older browsers. -->
    <?php
    $svg_path = get_template_directory() . '/assets/images/logo.svg';
    if ( file_exists( $svg_path ) ) {
        $svg = file_get_contents( $svg_path );
        // Normalize quotes and whitespace to be safe inside the data URI
        $svg = trim( preg_replace('/\s+/', ' ', $svg) );
        $svg = str_replace('"', "'", $svg);
        $svg_data = 'data:image/svg+xml;utf8,' . rawurlencode( $svg );
        // Inline data-uri (fast) and explicit file link (some browsers prefer the file)
        echo '<link rel="icon" href="' . esc_url( $svg_data ) . '" type="image/svg+xml">';
        echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() . '/assets/images/logo.svg' ) . '" type="image/svg+xml">';
    }
    // Always include a classic favicon.ico fallback in the theme root
    echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() . '/favicon.ico' ) . '" type="image/x-icon">';
    ?>
    <meta name="theme-color" content="#0A0F1C">
    
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'engine-dynamo'); ?></a>

    <header id="masthead" class="site-header">
        <div class="container">
            <div class="header-content">
                <!-- Left: Logo -->
                <div class="site-branding header-left">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo" rel="home">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.svg" alt="Engine Dynamo" />
                            <div class="logo-text">
                                <span class="engine">ENGINE</span>
                                <span class="dynamo">DYNAMO</span>
                            </div>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Center: Navigation -->
                <nav id="site-navigation" class="main-navigation header-center" aria-label="Primary Navigation">
                    <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                        <span class="hamburger"></span>
                        <span class="hamburger"></span>
                        <span class="hamburger"></span>
                    </button>
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'menu_id'        => 'primary-menu',
                        'menu_class'     => 'nav-menu centered-nav',
                        'container'      => false,
                        'fallback_cb'    => 'engine_dynamo_fallback_menu',
                        'walker'         => new Engine_Dynamo_Nav_Walker(),
                    ));
                    ?>
                </nav>

                <!-- Right: Search + Social -->
                <div class="header-controls header-right">
                    <div class="search-container">
                        <?php get_search_form(); ?>
                    </div>
                    <div class="header-social">
                        <a href="https://www.facebook.com/profile.php?id=61580498813187" class="social-icon facebook" target="_blank" rel="noopener">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://www.instagram.com/engine_dynamo/" class="social-icon instagram" target="_blank" rel="noopener">
                            <i class="fab fa-instagram"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
